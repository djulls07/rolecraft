(function () {



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['nemo64:bootstrap'] = {};

})();
