(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var RoutePolicy = Package.routepolicy.RoutePolicy;
var WebApp = Package.webapp.WebApp;
var main = Package.webapp.main;
var WebAppInternals = Package.webapp.WebAppInternals;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var Buffer = Package.modules.Buffer;
var process = Package.modules.process;
var Symbol = Package['ecmascript-runtime'].Symbol;
var Map = Package['ecmascript-runtime'].Map;
var Set = Package['ecmascript-runtime'].Set;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"xcv58:collection-api":{"lib":{"index.js":["./collection-api",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/xcv58_collection-api/lib/index.js                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.import('./collection-api',{"CollectionAPI":function(v){exports.CollectionAPI=v}});                              // 1
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"collection-api.js":["babel-runtime/helpers/classCallCheck","fibers","https","http","fs","meteor/webapp","meteor/routepolicy","./request-listener","./util",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/xcv58_collection-api/lib/collection-api.js                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({CollectionAPI:function(){return CollectionAPI}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var fibers;module.import('fibers',{"default":function(v){fibers=v}});var https;module.import('https',{"default":function(v){https=v}});var http;module.import('http',{"default":function(v){http=v}});var fs;module.import('fs',{"default":function(v){fs=v}});var WebApp;module.import('meteor/webapp',{"WebApp":function(v){WebApp=v}});var RoutePolicy;module.import('meteor/routepolicy',{"RoutePolicy":function(v){RoutePolicy=v}});var RequestListener;module.import('./request-listener',{"RequestListener":function(v){RequestListener=v}});var getNestedValue,getDefaultOptions;module.import('./util',{"getNestedValue":function(v){getNestedValue=v},"getDefaultOptions":function(v){getDefaultOptions=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       // 4
                                                                                                                       //
                                                                                                                       // 6
                                                                                                                       // 7
                                                                                                                       //
                                                                                                                       // 9
                                                                                                                       // 10
                                                                                                                       //
var CollectionAPI = function () {                                                                                      //
  function CollectionAPI() {                                                                                           // 13
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};                              // 13
                                                                                                                       //
    _classCallCheck(this, CollectionAPI);                                                                              // 13
                                                                                                                       //
    this.version = '0.3.0';                                                                                            // 14
    this._collections = {};                                                                                            // 15
    this.options = getDefaultOptions();                                                                                // 16
    Object.assign(this.options, options);                                                                              // 17
  }                                                                                                                    // 18
                                                                                                                       //
  CollectionAPI.prototype.addCollection = function () {                                                                //
    function addCollection(collection, path) {                                                                         //
      var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};                            // 20
                                                                                                                       //
      var collectionOptions = {};                                                                                      // 21
      collectionOptions[path] = { collection: collection, options: options };                                          // 22
      Object.assign(this._collections, collectionOptions);                                                             // 23
    }                                                                                                                  // 24
                                                                                                                       //
    return addCollection;                                                                                              //
  }();                                                                                                                 //
                                                                                                                       //
  CollectionAPI.prototype.start = function () {                                                                        //
    function start() {                                                                                                 //
      var _this = this;                                                                                                // 26
                                                                                                                       //
      var startupMessage = 'Collection API v' + this.version;                                                          // 27
                                                                                                                       //
      if (this.options.standAlone === true) {                                                                          // 29
        var httpServer = http;                                                                                         // 30
        var scheme = 'http://';                                                                                        // 31
        var httpOptions = {};                                                                                          // 32
                                                                                                                       //
        if (this.options.sslEnabled === true) {                                                                        // 34
          scheme = 'https://';                                                                                         // 35
          httpServer = https;                                                                                          // 36
          httpOptions = {                                                                                              // 37
            key: fs.readFileSync(this.options.privateKeyFile),                                                         // 38
            cert: fs.readFileSync(this.options.certificateFile)                                                        // 39
          };                                                                                                           // 37
        }                                                                                                              // 41
                                                                                                                       //
        this._httpServer = httpServer.createServer(httpOptions);                                                       // 43
        if (this.options.sslEnabled !== true) {                                                                        // 44
          this._httpServer.setTimeout(this.options.timeOut);                                                           // 45
        }                                                                                                              // 46
        this._httpServer.addListener('request', function (request, response) {                                         // 47
          if (_this.options.sslEnabled === true) {                                                                     // 48
            /* eslint-disable */                                                                                       // 49
            var requestTimeout = function () {                                                                         // 48
              function requestTimeout() {                                                                              // 50
                request.abort();                                                                                       // 51
              }                                                                                                        // 52
                                                                                                                       //
              return requestTimeout;                                                                                   // 48
            }();                                                                                                       // 48
                                                                                                                       //
            var responseTimeout = function () {                                                                        // 48
              function responseTimeout() {                                                                             // 54
                response.send(500, 'TIMEOUT');                                                                         // 55
              }                                                                                                        // 56
                                                                                                                       //
              return responseTimeout;                                                                                  // 48
            }();                                                                                                       // 48
            /* eslint-enable */                                                                                        // 57
                                                                                                                       //
            request.setTimeout(_this.options.timeOut, requestTimeout);                                                 // 59
            response.setTimeout(_this.options.timeOut, responseTimeout);                                               // 60
          }                                                                                                            // 61
          /* eslint-disable */                                                                                         // 62
          new RequestListener(_this, request, response);                                                               // 63
          /* eslint-enable */                                                                                          // 64
        });                                                                                                            // 65
                                                                                                                       //
        var _options = this.options;                                                                                   // 29
        var _options$listenHost = _options.listenHost;                                                                 // 29
        var listenHost = _options$listenHost === undefined ? 'localhost' : _options$listenHost;                        // 29
        var listenPort = _options.listenPort;                                                                          // 29
        var _options$apiPath = _options.apiPath;                                                                       // 29
        var apiPath = _options$apiPath === undefined ? '' : _options$apiPath;                                          // 29
                                                                                                                       //
                                                                                                                       //
        this._httpServer.listen(listenPort, listenHost);                                                               // 69
                                                                                                                       //
        /* eslint-disable */                                                                                           // 71
        console.log(startupMessage, 'running as a stand-alone server on', '' + scheme + listenHost + ':' + listenPort + '/' + apiPath);
        /* eslint-enable */                                                                                            // 77
      } else {                                                                                                         // 78
        RoutePolicy.declare('/' + this.options.apiPath + '/', 'network');                                              // 79
                                                                                                                       //
        WebApp.connectHandlers.use(function (req, res, next) {                                                         // 81
          if (req.url.split('/')[1] !== _this.options.apiPath) {                                                       // 82
            next();                                                                                                    // 83
            return;                                                                                                    // 84
          }                                                                                                            // 85
          fibers(function () {                                                                                         // 86
            return new RequestListener(_this, req, res);                                                               // 86
          }).run();                                                                                                    // 86
        });                                                                                                            // 87
                                                                                                                       //
        /* eslint-disable */                                                                                           // 89
        console.log(startupMessage + ' running at /' + this.options.apiPath);                                          // 90
        /* eslint-enable */                                                                                            // 91
      }                                                                                                                // 92
    }                                                                                                                  // 93
                                                                                                                       //
    return start;                                                                                                      //
  }();                                                                                                                 //
                                                                                                                       //
  CollectionAPI.prototype._getCollectionOptions = function () {                                                        //
    function _getCollectionOptions(_ref) {                                                                             //
      var collectionPath = _ref.collectionPath;                                                                        // 95
                                                                                                                       //
      return getNestedValue(this._collections, [collectionPath, 'options']);                                           // 96
    }                                                                                                                  // 97
                                                                                                                       //
    return _getCollectionOptions;                                                                                      //
  }();                                                                                                                 //
                                                                                                                       //
  CollectionAPI.prototype._getCollection = function () {                                                               //
    function _getCollection(_ref2) {                                                                                   //
      var collectionPath = _ref2.collectionPath;                                                                       // 99
                                                                                                                       //
      return getNestedValue(this._collections, [collectionPath, 'collection']);                                        // 100
    }                                                                                                                  // 101
                                                                                                                       //
    return _getCollection;                                                                                             //
  }();                                                                                                                 //
                                                                                                                       //
  return CollectionAPI;                                                                                                //
}();                                                                                                                   //
                                                                                                                       //
                                                                                                                       // 104
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"request-listener.js":["babel-runtime/helpers/classCallCheck","fibers","url","querystring","./util",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/xcv58_collection-api/lib/request-listener.js                                                               //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({RequestListener:function(){return RequestListener}});var _classCallCheck;module.import('babel-runtime/helpers/classCallCheck',{"default":function(v){_classCallCheck=v}});var fibers;module.import('fibers',{"default":function(v){fibers=v}});var url;module.import('url',{"default":function(v){url=v}});var querystring;module.import('querystring',{"default":function(v){querystring=v}});var isFunction,getReturnObject,getNestedValue;module.import('./util',{"isFunction":function(v){isFunction=v},"getReturnObject":function(v){getReturnObject=v},"getNestedValue":function(v){getNestedValue=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
                                                                                                                       // 5
var stringify = JSON.stringify;                                                                                        //
                                                                                                                       //
var RequestListener = function () {                                                                                    //
  function RequestListener(server, request, response) {                                                                // 9
    _classCallCheck(this, RequestListener);                                                                            // 9
                                                                                                                       //
    this._server = server;                                                                                             // 10
    this._request = request;                                                                                           // 11
    this._response = response;                                                                                         // 12
                                                                                                                       //
    if (server.options.allowCORS === true) {                                                                           // 14
      response.setHeader('Access-Control-Allow-Origin', '*');                                                          // 15
    }                                                                                                                  // 16
                                                                                                                       //
    this._requestUrl = url.parse(this._request.url, true);                                                             // 18
                                                                                                                       //
    // Check for the X-Auth-Token header or auth-token in the query string                                             // 20
    this._requestAuthToken = this._request.headers['x-auth-token'];                                                    // 21
    if (!this._requestAuthToken) {                                                                                     // 22
      this._requestAuthToken = querystring.parse(this._requestUrl.query)['auth-token'];                                // 23
    }                                                                                                                  // 24
                                                                                                                       //
    var requestPath = void 0;                                                                                          // 26
    var pathName = this._requestUrl.pathname;                                                                          // 27
    if (pathName.charAt(pathName.length - 1) === '/') {                                                                // 28
      pathName = pathName.substring(0, pathName.length - 1);                                                           // 29
    }                                                                                                                  // 30
                                                                                                                       //
    if (this._server.options.standAlone === true && !this._server.options.apiPath) {                                   // 32
      requestPath = pathName.split('/').slice(1);                                                                      // 33
    } else {                                                                                                           // 34
      requestPath = pathName.split('/').slice(2);                                                                      // 35
    }                                                                                                                  // 36
                                                                                                                       //
    this._requestPath = {                                                                                              // 38
      collectionPath: requestPath[0],                                                                                  // 39
      collectionId: requestPath[1],                                                                                    // 40
      fields: requestPath.slice(2),                                                                                    // 41
      query: this._requestUrl.query                                                                                    // 42
    };                                                                                                                 // 38
                                                                                                                       //
    this._collectionOptions = this._server._getCollectionOptions(this._requestPath);                                   // 45
    this._requestCollection = this._server._getCollection(this._requestPath);                                          // 46
                                                                                                                       //
    if (!this._requestCollection) {                                                                                    // 48
      return this._notFoundResponse('Collection Object Not Found');                                                    // 49
    }                                                                                                                  // 50
                                                                                                                       //
    if (!this._authenticate(this._requestAuthToken, this._request.method, this._requestPath)) {                        // 52
      return this._unauthorizedResponse('Invalid/Missing Auth Token');                                                 // 53
    }                                                                                                                  // 54
                                                                                                                       //
    return this._handleRequest();                                                                                      // 56
  }                                                                                                                    // 57
                                                                                                                       //
  RequestListener.prototype._authenticate = function () {                                                              //
    function _authenticate() {                                                                                         //
      var collectionOptions = this._collectionOptions;                                                                 // 60
      var authCount = 0;                                                                                               // 61
                                                                                                                       //
      // Check the global auth token                                                                                   // 63
      if (this._server.options.authToken) {                                                                            // 64
        authCount++;                                                                                                   // 65
        if (this._requestAuthToken === this._server.options.authToken) {                                               // 66
          return true;                                                                                                 // 67
        }                                                                                                              // 68
      }                                                                                                                // 69
                                                                                                                       //
      // Check the collection's auth token                                                                             // 71
      if (collectionOptions && collectionOptions.authToken) {                                                          // 72
        authCount++;                                                                                                   // 73
        if (this._requestAuthToken === collectionOptions.authToken) {                                                  // 74
          return true;                                                                                                 // 75
        }                                                                                                              // 76
      }                                                                                                                // 77
                                                                                                                       //
      var authenticate = collectionOptions.authenticate;                                                               // 59
                                                                                                                       //
      if (!authCount && authenticate && isFunction(authenticate)) {                                                    // 80
        authCount++;                                                                                                   // 81
                                                                                                                       //
        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {                         // 80
          args[_key] = arguments[_key];                                                                                // 59
        }                                                                                                              // 80
                                                                                                                       //
        if (authenticate.apply(this, args)) {                                                                          // 82
          return true;                                                                                                 // 83
        }                                                                                                              // 84
      }                                                                                                                // 85
                                                                                                                       //
      return authCount === 0;                                                                                          // 87
    }                                                                                                                  // 88
                                                                                                                       //
    return _authenticate;                                                                                              //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype._handleRequest = function () {                                                             //
    function _handleRequest() {                                                                                        //
      var method = this._request.method;                                                                               // 90
                                                                                                                       //
                                                                                                                       //
      if (!this._requestMethodAllowed(method)) {                                                                       // 93
        return this._notSupportedResponse();                                                                           // 94
      }                                                                                                                // 95
                                                                                                                       //
      var func = this[method.toLowerCase()];                                                                           // 97
      if (isFunction(func)) {                                                                                          // 98
        return func.apply(this);                                                                                       // 99
      }                                                                                                                // 100
                                                                                                                       //
      return this._notSupportedResponse();                                                                             // 102
    }                                                                                                                  // 103
                                                                                                                       //
    return _handleRequest;                                                                                             //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype._requestMethodAllowed = function () {                                                      //
    function _requestMethodAllowed(method) {                                                                           //
      var collectionOptions = this._collectionOptions;                                                                 // 106
                                                                                                                       //
      var _ref = collectionOptions || {};                                                                              // 105
                                                                                                                       //
      var _ref$methods = _ref.methods;                                                                                 // 105
      var methods = _ref$methods === undefined ? [] : _ref$methods;                                                    // 105
                                                                                                                       //
      return methods.indexOf(method) >= 0;                                                                             // 109
    }                                                                                                                  // 110
                                                                                                                       //
    return _requestMethodAllowed;                                                                                      //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype._handleHooks = function () {                                                               //
    function _handleHooks(hook, method, args) {                                                                        //
      var func = getNestedValue(this._collectionOptions, [hook, method]);                                              // 113
      if (isFunction(func)) {                                                                                          // 114
        return func.apply(this, args);                                                                                 // 115
      }                                                                                                                // 116
                                                                                                                       //
      return true;                                                                                                     // 118
    }                                                                                                                  // 119
                                                                                                                       //
    return _handleHooks;                                                                                               //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype._beforeHandling = function () {                                                            //
    function _beforeHandling(method) {                                                                                 //
      for (var _len2 = arguments.length, args = Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
        args[_key2 - 1] = arguments[_key2];                                                                            // 121
      }                                                                                                                // 121
                                                                                                                       //
      return this._handleHooks.apply(this, ['before', method, args]);                                                  // 122
    }                                                                                                                  // 123
                                                                                                                       //
    return _beforeHandling;                                                                                            //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype._afterHandling = function () {                                                             //
    function _afterHandling(method) {                                                                                  //
      for (var _len3 = arguments.length, args = Array(_len3 > 1 ? _len3 - 1 : 0), _key3 = 1; _key3 < _len3; _key3++) {
        args[_key3 - 1] = arguments[_key3];                                                                            // 125
      }                                                                                                                // 125
                                                                                                                       //
      return this._handleHooks.apply(this, ['after', method, args]);                                                   // 126
    }                                                                                                                  // 127
                                                                                                                       //
    return _afterHandling;                                                                                             //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype._handleReturnObject = function () {                                                        //
    function _handleReturnObject(method, returnObject) {                                                               //
      if (returnObject.success && returnObject.statusCode && returnObject.body) {                                      // 130
        this._afterHandling(method);                                                                                   // 131
        return this._sendResponse(returnObject.statusCode, stringify(returnObject.body));                              // 132
      }                                                                                                                // 133
      return false;                                                                                                    // 134
    }                                                                                                                  // 135
                                                                                                                       //
    return _handleReturnObject;                                                                                        //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype.get = function () {                                                                        //
    function get() {                                                                                                   //
      var _this = this;                                                                                                // 137
                                                                                                                       //
      var fromRequest = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'GET';                     // 137
                                                                                                                       //
      fibers(function () {                                                                                             // 138
        try {                                                                                                          // 139
          var collectionId = _this._requestPath.collectionId;                                                          // 139
                                                                                                                       //
          var cursor = null;                                                                                           // 141
          if (collectionId) {                                                                                          // 142
            cursor = _this._requestCollection.find(_this._requestPath.collectionId);                                   // 143
          } else {                                                                                                     // 144
            cursor = _this._requestCollection.find();                                                                  // 145
          }                                                                                                            // 146
                                                                                                                       //
          var records = cursor.fetch();                                                                                // 148
                                                                                                                       //
          var returnObject = getReturnObject();                                                                        // 150
                                                                                                                       //
          if (!_this._beforeHandling('GET', records, _this._requestPath, returnObject)) {                              // 152
            if (fromRequest) {                                                                                         // 153
              if (records.length) {                                                                                    // 154
                return _this._noContentResponse();                                                                     // 155
              }                                                                                                        // 156
              return _this._notFoundResponse('No Record(s) Found');                                                    // 157
            }                                                                                                          // 158
            return _this._rejectedResponse('Could not get that collection/object.');                                   // 159
          }                                                                                                            // 160
                                                                                                                       //
          if (_this._handleReturnObject('GET', returnObject)) {                                                        // 162
            return true;                                                                                               // 163
          }                                                                                                            // 164
                                                                                                                       //
          if (records.length === 0) {                                                                                  // 166
            return _this._notFoundResponse('No Record(s) Found');                                                      // 167
          }                                                                                                            // 168
                                                                                                                       //
          _this._afterHandling('GET');                                                                                 // 170
                                                                                                                       //
          if (fromRequest === 'POST') {                                                                                // 172
            return _this._createdResponse(stringify(records));                                                         // 173
          }                                                                                                            // 174
                                                                                                                       //
          return _this._okResponse(stringify(records));                                                                // 176
        } catch (e) {                                                                                                  // 177
          return _this._internalServerErrorResponse(e);                                                                // 178
        }                                                                                                              // 179
      }).run();                                                                                                        // 180
    }                                                                                                                  // 181
                                                                                                                       //
    return get;                                                                                                        //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype.put = function () {                                                                        //
    function put() {                                                                                                   //
      var _this2 = this;                                                                                               // 183
                                                                                                                       //
      if (!this._requestPath.collectionId) {                                                                           // 184
        return this._notFoundResponse('Missing _id');                                                                  // 185
      }                                                                                                                // 186
                                                                                                                       //
      var requestData = '';                                                                                            // 188
                                                                                                                       //
      this._request.on('data', function (chunk) {                                                                      // 190
        requestData += chunk.toString();                                                                               // 191
      });                                                                                                              // 192
                                                                                                                       //
      return this._request.on('end', function () {                                                                     // 194
        fibers(function () {                                                                                           // 195
          try {                                                                                                        // 196
            var obj = JSON.parse(requestData);                                                                         // 197
                                                                                                                       //
            var returnObject = getReturnObject();                                                                      // 199
                                                                                                                       //
            if (!_this2._beforeHandling('PUT', _this2._requestCollection.findOne(_this2._requestPath.collectionId), obj, _this2._requestPath, returnObject)) {
              return _this2._rejectedResponse('Could not put that object.');                                           // 208
            }                                                                                                          // 209
                                                                                                                       //
            if (_this2._handleReturnObject('PUT', returnObject)) {                                                     // 211
              return true;                                                                                             // 212
            }                                                                                                          // 213
                                                                                                                       //
            _this2._requestCollection.update(_this2._requestPath.collectionId, obj);                                   // 215
          } catch (e) {                                                                                                // 216
            return _this2._internalServerErrorResponse(e);                                                             // 217
          }                                                                                                            // 218
                                                                                                                       //
          _this2._afterHandling('PUT');                                                                                // 220
          if (_this2._requestPath.query.callback === '0') {                                                            // 221
            return _this2._createdResponse(stringify({ status: 'success' }));                                          // 222
          }                                                                                                            // 223
          return _this2.get('PUT');                                                                                    // 224
        }).run();                                                                                                      // 225
      });                                                                                                              // 226
    }                                                                                                                  // 227
                                                                                                                       //
    return put;                                                                                                        //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype['delete'] = function () {                                                                  //
    function _delete() {                                                                                               //
      var _this3 = this;                                                                                               // 229
                                                                                                                       //
      if (!this._requestPath.collectionId) {                                                                           // 230
        return this._notFoundResponse('Missing _id');                                                                  // 231
      }                                                                                                                // 232
                                                                                                                       //
      return fibers(function () {                                                                                      // 234
        try {                                                                                                          // 235
          var returnObject = getReturnObject();                                                                        // 236
                                                                                                                       //
          if (!_this3._beforeHandling('DELETE', _this3._requestCollection.findOne(_this3._requestPath.collectionId), _this3._requestPath, returnObject)) {
            return _this3._rejectedResponse('Could not delete that object.');                                          // 244
          }                                                                                                            // 245
                                                                                                                       //
          if (_this3._handleReturnObject('DELETE', returnObject)) {                                                    // 247
            return true;                                                                                               // 248
          }                                                                                                            // 249
                                                                                                                       //
          _this3._requestCollection.remove(_this3._requestPath.collectionId);                                          // 251
        } catch (e) {                                                                                                  // 252
          return _this3._internalServerErrorResponse(e);                                                               // 253
        }                                                                                                              // 254
        _this3._afterHandling('DELETE');                                                                               // 255
        return _this3._okResponse('');                                                                                 // 256
      }).run();                                                                                                        // 257
    }                                                                                                                  // 258
                                                                                                                       //
    return _delete;                                                                                                    //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype.post = function () {                                                                       //
    function post() {                                                                                                  //
      var _this4 = this;                                                                                               // 260
                                                                                                                       //
      var requestData = '';                                                                                            // 261
                                                                                                                       //
      this._request.on('data', function (chunk) {                                                                      // 263
        requestData += chunk.toString();                                                                               // 264
      });                                                                                                              // 265
                                                                                                                       //
      this._request.on('end', function () {                                                                            // 267
        fibers(function () {                                                                                           // 268
          try {                                                                                                        // 269
            var obj = JSON.parse(requestData);                                                                         // 270
                                                                                                                       //
            var returnObject = getReturnObject();                                                                      // 272
                                                                                                                       //
            if (!_this4._beforeHandling('POST', obj, _this4._requestPath, returnObject)) {                             // 274
              return _this4._rejectedResponse('Could not post that object.');                                          // 275
            }                                                                                                          // 276
                                                                                                                       //
            if (_this4._handleReturnObject('POST', returnObject)) {                                                    // 278
              return true;                                                                                             // 279
            }                                                                                                          // 280
                                                                                                                       //
            _this4._requestPath.collectionId = _this4._requestCollection.insert(obj);                                  // 282
          } catch (e) {                                                                                                // 283
            return _this4._internalServerErrorResponse(e);                                                             // 284
          }                                                                                                            // 285
          _this4._afterHandling('POST');                                                                               // 286
          return _this4.get('POST');                                                                                   // 287
        }).run();                                                                                                      // 288
      });                                                                                                              // 289
    }                                                                                                                  // 290
                                                                                                                       //
    return post;                                                                                                       //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype._okResponse = function () {                                                                //
    function _okResponse(body) {                                                                                       //
      this._sendResponse(200, body);                                                                                   // 293
    }                                                                                                                  // 294
                                                                                                                       //
    return _okResponse;                                                                                                //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype._createdResponse = function () {                                                           //
    function _createdResponse(body) {                                                                                  //
      this._sendResponse(201, body);                                                                                   // 297
    }                                                                                                                  // 298
                                                                                                                       //
    return _createdResponse;                                                                                           //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype._noContentResponse = function () {                                                         //
    function _noContentResponse() {                                                                                    //
      this._sendResponse(204, '');                                                                                     // 301
    }                                                                                                                  // 302
                                                                                                                       //
    return _noContentResponse;                                                                                         //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype._notSupportedResponse = function () {                                                      //
    function _notSupportedResponse() {                                                                                 //
      this._sendResponse(501, '');                                                                                     // 305
    }                                                                                                                  // 306
                                                                                                                       //
    return _notSupportedResponse;                                                                                      //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype._unauthorizedResponse = function () {                                                      //
    function _unauthorizedResponse(body) {                                                                             //
      this._sendResponse(401, stringify({ message: body.toString() }));                                                // 309
    }                                                                                                                  // 310
                                                                                                                       //
    return _unauthorizedResponse;                                                                                      //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype._notFoundResponse = function () {                                                          //
    function _notFoundResponse(body) {                                                                                 //
      this._sendResponse(404, stringify({ message: body.toString() }));                                                // 313
    }                                                                                                                  // 314
                                                                                                                       //
    return _notFoundResponse;                                                                                          //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype._rejectedResponse = function () {                                                          //
    function _rejectedResponse(body) {                                                                                 //
      this._sendResponse(409, stringify({ message: body.toString() }));                                                // 317
    }                                                                                                                  // 318
                                                                                                                       //
    return _rejectedResponse;                                                                                          //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype._internalServerErrorResponse = function () {                                               //
    function _internalServerErrorResponse(body) {                                                                      //
      this._sendResponse(500, stringify({ error: body.toString() }));                                                  // 321
    }                                                                                                                  // 322
                                                                                                                       //
    return _internalServerErrorResponse;                                                                               //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype._notSupportedResponse = function () {                                                      //
    function _notSupportedResponse() {                                                                                 //
      this._sendResponse(501, '');                                                                                     // 325
    }                                                                                                                  // 326
                                                                                                                       //
    return _notSupportedResponse;                                                                                      //
  }();                                                                                                                 //
                                                                                                                       //
  RequestListener.prototype._sendResponse = function () {                                                              //
    function _sendResponse(statusCode, body) {                                                                         //
      this._response.statusCode = statusCode;                                                                          // 329
      this._response.setHeader('Content-Length', Buffer.byteLength(body, 'utf8'));                                     // 330
      this._response.setHeader('Content-Type', 'application/json');                                                    // 331
      this._response.write(body);                                                                                      // 332
      this._response.end();                                                                                            // 333
      return true;                                                                                                     // 334
    }                                                                                                                  // 335
                                                                                                                       //
    return _sendResponse;                                                                                              //
  }();                                                                                                                 //
                                                                                                                       //
  return RequestListener;                                                                                              //
}();                                                                                                                   //
                                                                                                                       //
                                                                                                                       // 338
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"util.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// packages/xcv58_collection-api/lib/util.js                                                                           //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({isFunction:function(){return isFunction},getReturnObject:function(){return getReturnObject},getNestedValue:function(){return getNestedValue},getDefaultOptions:function(){return getDefaultOptions}});var getDefaultOptions = function getDefaultOptions() {
  return {                                                                                                             // 1
    apiPath: 'collectionapi',                                                                                          // 2
    standAlone: false,                                                                                                 // 3
    allowCORS: false,                                                                                                  // 4
    sslEnabled: false,                                                                                                 // 5
    listenPort: 3005,                                                                                                  // 6
    listenHost: null,                                                                                                  // 7
    authToken: null,                                                                                                   // 8
    privateKeyFile: 'privatekey.pem',                                                                                  // 9
    certificateFile: 'certificate.pem',                                                                                // 10
    timeOut: 120000                                                                                                    // 11
  };                                                                                                                   // 1
};                                                                                                                     // 1
                                                                                                                       //
var getReturnObject = function getReturnObject() {                                                                     // 14
  return { success: false, statusCode: null, body: null };                                                             // 14
};                                                                                                                     // 14
                                                                                                                       //
var isFunction = function isFunction(func) {                                                                           // 16
  return typeof func === 'function';                                                                                   // 16
};                                                                                                                     // 16
                                                                                                                       //
var getNestedValue = function getNestedValue(obj) {                                                                    // 18
  var keys = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];                                   // 18
                                                                                                                       //
  var res = obj;                                                                                                       // 19
  for (var _iterator = keys, _isArray = Array.isArray(_iterator), _i = 0, _iterator = _isArray ? _iterator : _iterator[Symbol.iterator]();;) {
    var _ref;                                                                                                          // 20
                                                                                                                       //
    if (_isArray) {                                                                                                    // 20
      if (_i >= _iterator.length) break;                                                                               // 20
      _ref = _iterator[_i++];                                                                                          // 20
    } else {                                                                                                           // 20
      _i = _iterator.next();                                                                                           // 20
      if (_i.done) break;                                                                                              // 20
      _ref = _i.value;                                                                                                 // 20
    }                                                                                                                  // 20
                                                                                                                       //
    var key = _ref;                                                                                                    // 20
                                                                                                                       //
    if (Boolean(res)) {                                                                                                // 21
      res = res[key];                                                                                                  // 22
    } else {                                                                                                           // 23
      return res;                                                                                                      // 24
    }                                                                                                                  // 25
  }                                                                                                                    // 26
  return res;                                                                                                          // 27
};                                                                                                                     // 28
                                                                                                                       //
                                                                                                                       // 30
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"node_modules":{"fibers":{"package.json":function(require,exports){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// ../../.0.3.0.1ykzprv++os.linux.x86_64+web.browser+web.cordova/npm/node_modules/fibers/package.json                  //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
exports.name = "fibers";
exports.version = "1.0.10";
exports.main = "fibers";

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"fibers.js":function(require,exports,module,__filename,__dirname){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// node_modules/meteor/xcv58:collection-api/node_modules/fibers/fibers.js                                              //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
if (process.fiberLib) {
	return module.exports = process.fiberLib;
}
var fs = require('fs'), path = require('path');

// Seed random numbers [gh-82]
Math.random();

// Look for binary for this platform
var v8 = 'v8-'+ /[0-9]+\.[0-9]+/.exec(process.versions.v8)[0];
var modPath = path.join(__dirname, 'bin', process.platform+ '-'+ process.arch+ '-'+ v8, 'fibers');
try {
	fs.statSync(modPath+ '.node');
} catch (ex) {
	// No binary!
	throw new Error('`'+ modPath+ '.node` is missing. Try reinstalling `node-fibers`?');
}

// Pull in fibers implementation
process.fiberLib = module.exports = require(modPath).Fiber;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}}}},{"extensions":[".js",".json"]});
var exports = require("./node_modules/meteor/xcv58:collection-api/lib/index.js");

/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['xcv58:collection-api'] = exports;

})();

//# sourceMappingURL=xcv58_collection-api.js.map
