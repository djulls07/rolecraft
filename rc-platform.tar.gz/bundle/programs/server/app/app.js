var require = meteorInstall({"imports":{"api":{"db-init":{"translations.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/db-init/translations.js                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({translations:function(){return translations}});var translations = [{                                    // 1
  "key": "sheets",                                                                                                     // 3
  "fr": "feuilles",                                                                                                    // 4
  "en": "sheets"                                                                                                       // 5
}, {                                                                                                                   // 2
  "key": "model-sheets",                                                                                               // 8
  "fr": "modèles de feuilles",                                                                                         // 9
  "en": "model sheets"                                                                                                 // 10
}, {                                                                                                                   // 7
  "key": "model-sheet",                                                                                                // 13
  "fr": "modèle",                                                                                                      // 14
  "en": "model"                                                                                                        // 15
}, {                                                                                                                   // 12
  "key": "please-login",                                                                                               // 18
  "fr": "veuillez vous connecter",                                                                                     // 19
  "en": "please log in"                                                                                                // 20
}, {                                                                                                                   // 17
  "key": "login-to-continue",                                                                                          // 23
  "fr": "veuillez vous connecter pour continuer",                                                                      // 24
  "en": "please log in to continue"                                                                                    // 25
}, {                                                                                                                   // 22
  "key": "to-add-model",                                                                                               // 28
  "fr": "pour ajouter de nouveau modèle de feuille",                                                                   // 29
  "en": "to add model sheet"                                                                                           // 30
}, {                                                                                                                   // 27
  "key": "open-drawing",                                                                                               // 33
  "fr": "ouvrir le module de dessin",                                                                                  // 34
  "en": "open drawing component"                                                                                       // 35
}, {                                                                                                                   // 32
  "key": "my-files",                                                                                                   // 38
  "fr": "mes fichiers",                                                                                                // 39
  "en": "my files"                                                                                                     // 40
}, {                                                                                                                   // 37
  "key": "clone-section",                                                                                              // 43
  "fr": "cloner la section",                                                                                           // 44
  "en": "clone section"                                                                                                // 45
}, {                                                                                                                   // 42
  "key": "mode-organize",                                                                                              // 48
  "fr": "drag&drop",                                                                                                   // 49
  "en": "drag&drop"                                                                                                    // 50
}, {                                                                                                                   // 47
  "key": "mode-normal",                                                                                                // 53
  "fr": "normal",                                                                                                      // 54
  "en": "normal"                                                                                                       // 55
}, {                                                                                                                   // 52
  "key": "export",                                                                                                     // 58
  "fr": "exporter",                                                                                                    // 59
  "en": "export"                                                                                                       // 60
}, {                                                                                                                   // 57
  "key": "import",                                                                                                     // 63
  "fr": "importer",                                                                                                    // 64
  "en": "import"                                                                                                       // 65
}, {                                                                                                                   // 62
  "key": "upload-new-file",                                                                                            // 68
  "fr": "téléverser nouveau fichier",                                                                                  // 69
  "en": "upload new file"                                                                                              // 70
}, {                                                                                                                   // 67
  "key": "optional",                                                                                                   // 73
  "fr": "facultatif",                                                                                                  // 74
  "en": "optional"                                                                                                     // 75
}, {                                                                                                                   // 72
  "key": "notes",                                                                                                      // 78
  "fr": "notes",                                                                                                       // 79
  "en": "notes"                                                                                                        // 80
}, {                                                                                                                   // 77
  "key": "new-note",                                                                                                   // 83
  "fr": "nouvelle note",                                                                                               // 84
  "en": "new note"                                                                                                     // 85
}, {                                                                                                                   // 82
  "key": "set-edit-mode",                                                                                              // 88
  "fr": "mode edition",                                                                                                // 89
  "en": "edition mode"                                                                                                 // 90
}, {                                                                                                                   // 87
  "key": "set-selection-mode",                                                                                         // 93
  "fr": "mode selection",                                                                                              // 94
  "en": "selection mode"                                                                                               // 95
}, {                                                                                                                   // 92
  "key": "save-on-change",                                                                                             // 98
  "fr": "le modèle est sauvé régulièrement ( a chaque changements )",                                                  // 99
  "en": "model is saved regularly ( on every changes )"                                                                // 100
}, {                                                                                                                   // 97
  "key": "search-model-sheet",                                                                                         // 103
  "fr": "chercher parmis les feuilles",                                                                                // 104
  "en": "search in sheets"                                                                                             // 105
}, {                                                                                                                   // 102
  "key": "default-model-sheet",                                                                                        // 108
  "fr": "feuille du jeu de rôle",                                                                                      // 109
  "en": "role plaing game sheet"                                                                                       // 110
}, {                                                                                                                   // 107
  "key": "shared-files",                                                                                               // 113
  "fr": "fichiers partagés avec moi",                                                                                  // 114
  "en": "files shared with me"                                                                                         // 115
}, {                                                                                                                   // 112
  "key": "upload",                                                                                                     // 118
  "fr": "téléverser",                                                                                                  // 119
  "en": "upload"                                                                                                       // 120
}, {                                                                                                                   // 117
  "key": "download",                                                                                                   // 123
  "fr": "télécharger",                                                                                                 // 124
  "en": "download"                                                                                                     // 125
}, {                                                                                                                   // 122
  "key": "no-model-sheet",                                                                                             // 128
  "fr": "aucun modèle de feuille",                                                                                     // 129
  "en": "no model sheet"                                                                                               // 130
}, {                                                                                                                   // 127
  "key": "roll-example",                                                                                               // 133
  "fr": "2d100 ou 2d100, 3d20, 1d6 etc etc...",                                                                        // 134
  "en": "2d100 or 2d100, 3d20, 1d6 etc etc..."                                                                         // 135
}, {                                                                                                                   // 132
  "key": "add-model-sheet",                                                                                            // 138
  "fr": "ajouter un modèle de feuille",                                                                                // 139
  "en": "add model sheet"                                                                                              // 140
}, {                                                                                                                   // 137
  "key": "remove-section",                                                                                             // 143
  "fr": "supprimer la section",                                                                                        // 144
  "en": "remove section"                                                                                               // 145
}, {                                                                                                                   // 142
  "key": "remove-element",                                                                                             // 148
  "fr": "supprimer l'élément",                                                                                         // 149
  "en": "remove element"                                                                                               // 150
}, {                                                                                                                   // 147
  "key": "empty-if-user-fill-it",                                                                                      // 153
  "fr": "laissez les cases vides si elles doivent être éditables",                                                     // 154
  "en": "let entries empty if players have to fill them"                                                               // 155
}, {                                                                                                                   // 152
  "key": "row-number",                                                                                                 // 158
  "fr": "nombre de lignes",                                                                                            // 159
  "en": "number of rows"                                                                                               // 160
}, {                                                                                                                   // 157
  "key": "col-number",                                                                                                 // 163
  "fr": "nombre de colones",                                                                                           // 164
  "en": "number of columns"                                                                                            // 165
}, {                                                                                                                   // 162
  "key": "enter-size",                                                                                                 // 168
  "fr": "entrez une taille",                                                                                           // 169
  "en": "enter a size"                                                                                                 // 170
}, {                                                                                                                   // 167
  "key": "element-label",                                                                                              // 173
  "fr": "libellé de l'élément",                                                                                        // 174
  "en": "element label"                                                                                                // 175
}, {                                                                                                                   // 172
  "key": "section-name",                                                                                               // 178
  "fr": "nom de la section",                                                                                           // 179
  "en": "name of the section"                                                                                          // 180
}, {                                                                                                                   // 177
  "key": "edit-model-sheet",                                                                                           // 183
  "fr": "edition du modèle de feuille",                                                                                // 184
  "en": "editing model sheet"                                                                                          // 185
}, {                                                                                                                   // 182
  "key": "text-field",                                                                                                 // 188
  "fr": "champs de type texte",                                                                                        // 189
  "en": "text field"                                                                                                   // 190
}, {                                                                                                                   // 187
  "key": "table-field",                                                                                                // 193
  "fr": "champs de type tableau",                                                                                      // 194
  "en": "table field"                                                                                                  // 195
}, {                                                                                                                   // 192
  "key": "textarea-field",                                                                                             // 198
  "fr": "champs de type texte long",                                                                                   // 199
  "en": "long text field"                                                                                              // 200
}, {                                                                                                                   // 197
  "key": "edit",                                                                                                       // 203
  "fr": "modifier",                                                                                                    // 204
  "en": "edit"                                                                                                         // 205
}, {                                                                                                                   // 202
  "key": "who",                                                                                                        // 208
  "fr": "qui",                                                                                                         // 209
  "en": "who"                                                                                                          // 210
}, {                                                                                                                   // 207
  "key": "when",                                                                                                       // 213
  "fr": "quand",                                                                                                       // 214
  "en": "when"                                                                                                         // 215
}, {                                                                                                                   // 212
  "key": "what",                                                                                                       // 218
  "fr": "quoi",                                                                                                        // 219
  "en": "what"                                                                                                         // 220
}, {                                                                                                                   // 217
  "key": "value",                                                                                                      // 223
  "fr": "valeur",                                                                                                      // 224
  "en": "value"                                                                                                        // 225
}, {                                                                                                                   // 222
  "key": "cancel-change",                                                                                              // 228
  "fr": "annuler le changement",                                                                                       // 229
  "en": "cancel modification"                                                                                          // 230
}, {                                                                                                                   // 227
  "key": "sheets-histories",                                                                                           // 233
  "fr": "historiques des feuilles",                                                                                    // 234
  "en": "sheets histories"                                                                                             // 235
}, {                                                                                                                   // 232
  "key": "no-history",                                                                                                 // 238
  "fr": "pas d'historique",                                                                                            // 239
  "en": "no history"                                                                                                   // 240
}, {                                                                                                                   // 237
  "key": "previous-val",                                                                                               // 243
  "fr": "valeur précédente",                                                                                           // 244
  "en": "previous value"                                                                                               // 245
}, {                                                                                                                   // 242
  "key": "remove",                                                                                                     // 248
  "fr": "supprimer",                                                                                                   // 249
  "en": "remove"                                                                                                       // 250
}, {                                                                                                                   // 247
  "key": "view",                                                                                                       // 253
  "fr": "voir",                                                                                                        // 254
  "en": "view"                                                                                                         // 255
}, {                                                                                                                   // 252
  "key": "preview",                                                                                                    // 258
  "fr": "aperçu",                                                                                                      // 259
  "en": "preview"                                                                                                      // 260
}, {                                                                                                                   // 257
  "key": "no-name-section",                                                                                            // 263
  "fr": "section sans nom",                                                                                            // 264
  "en": "unamed section"                                                                                               // 265
}, {                                                                                                                   // 262
  "key": "add",                                                                                                        // 268
  "fr": "ajouter",                                                                                                     // 269
  "en": "add"                                                                                                          // 270
}, {                                                                                                                   // 267
  "key": "add-element",                                                                                                // 273
  "fr": "ajouter un élément",                                                                                          // 274
  "en": "add an element"                                                                                               // 275
}, {                                                                                                                   // 272
  "key": "model-sheet-list",                                                                                           // 278
  "fr": "liste des modèles de feuilles",                                                                               // 279
  "en": "model sheet list"                                                                                             // 280
}, {                                                                                                                   // 277
  "key": "choose-section",                                                                                             // 283
  "fr": "choisissez une section",                                                                                      // 284
  "en": "choose a section"                                                                                             // 285
}, {                                                                                                                   // 282
  "key": "full-size-section",                                                                                          // 288
  "fr": "section taille max",                                                                                          // 289
  "en": "full size section"                                                                                            // 290
}, {                                                                                                                   // 287
  "key": "2-3-size-section",                                                                                           // 293
  "fr": "section de taille 2/3",                                                                                       // 294
  "en": "2/3 size section"                                                                                             // 295
}, {                                                                                                                   // 292
  "key": "1-3-size-section",                                                                                           // 298
  "fr": "section de taille 1/3",                                                                                       // 299
  "en": "1/3 size section"                                                                                             // 300
}, {                                                                                                                   // 297
  "key": "1-2-size-section",                                                                                           // 303
  "fr": "section de taille 1/2",                                                                                       // 304
  "en": "1/2 size section"                                                                                             // 305
}, {                                                                                                                   // 302
  "key": "1-4-size-section",                                                                                           // 308
  "fr": "section de taille 1/4",                                                                                       // 309
  "en": "1/4 size section"                                                                                             // 310
}, {                                                                                                                   // 307
  "key": "choose-element-type",                                                                                        // 313
  "fr": "choisissez un type d'élément",                                                                                // 314
  "en": "choose a type of element"                                                                                     // 315
}, {                                                                                                                   // 312
  "key": "name",                                                                                                       // 318
  "fr": "nom",                                                                                                         // 319
  "en": "name"                                                                                                         // 320
}, {                                                                                                                   // 317
  "key": "password",                                                                                                   // 323
  "fr": "mot de passe",                                                                                                // 324
  "en": "password"                                                                                                     // 325
}, {                                                                                                                   // 322
  "key": "language",                                                                                                   // 328
  "fr": "langue",                                                                                                      // 329
  "en": "language"                                                                                                     // 330
}, {                                                                                                                   // 327
  "key": "create",                                                                                                     // 333
  "fr": "créer",                                                                                                       // 334
  "en": "create"                                                                                                       // 335
}, {                                                                                                                   // 332
  "key": "rpg-list",                                                                                                   // 338
  "fr": "liste des jeux de rôles",                                                                                     // 339
  "en": "role playing game list"                                                                                       // 340
}, {                                                                                                                   // 337
  "key": "role-master-online",                                                                                         // 343
  "fr": "maitre du jeu connecté",                                                                                      // 344
  "en": "role master connected"                                                                                        // 345
}, {                                                                                                                   // 342
  "key": "protected",                                                                                                  // 348
  "fr": "protegé",                                                                                                     // 349
  "en": "protected"                                                                                                    // 350
}, {                                                                                                                   // 347
  "key": "online",                                                                                                     // 353
  "fr": "en ligne",                                                                                                    // 354
  "en": "online"                                                                                                       // 355
}, {                                                                                                                   // 352
  "key": "offline",                                                                                                    // 358
  "fr": "hors ligne",                                                                                                  // 359
  "en": "offline"                                                                                                      // 360
}, {                                                                                                                   // 357
  "key": "game-open",                                                                                                  // 363
  "fr": "jeu ouvert",                                                                                                  // 364
  "en": "game is open"                                                                                                 // 365
}, {                                                                                                                   // 362
  "key": "yes",                                                                                                        // 368
  "fr": "oui",                                                                                                         // 369
  "en": "yes"                                                                                                          // 370
}, {                                                                                                                   // 367
  "key": "no",                                                                                                         // 373
  "fr": "non",                                                                                                         // 374
  "en": "no"                                                                                                           // 375
}, {                                                                                                                   // 372
  "key": "create-new-rpg",                                                                                             // 378
  "fr": "créer un nouveau jeu de rôle",                                                                                // 379
  "en": "create a new role playing game"                                                                               // 380
}, {                                                                                                                   // 377
  "key": "only-my-games",                                                                                              // 383
  "fr": "uniquement mes parties",                                                                                      // 384
  "en": "only my games"                                                                                                // 385
}, {                                                                                                                   // 382
  "key": "my-role",                                                                                                    // 388
  "fr": "mon rôle",                                                                                                    // 389
  "en": "my role"                                                                                                      // 390
}, {                                                                                                                   // 387
  "key": "role-master",                                                                                                // 393
  "fr": "maitre du jeu",                                                                                               // 394
  "en": "role master"                                                                                                  // 395
}, {                                                                                                                   // 392
  "key": "player",                                                                                                     // 398
  "fr": "joueur",                                                                                                      // 399
  "en": "player"                                                                                                       // 400
}, {                                                                                                                   // 397
  "key": "enter",                                                                                                      // 403
  "fr": "entrer",                                                                                                      // 404
  "en": "enter"                                                                                                        // 405
}, {                                                                                                                   // 402
  "key": "owner",                                                                                                      // 408
  "fr": "propriétaire",                                                                                                // 409
  "en": "owner"                                                                                                        // 410
}, {                                                                                                                   // 407
  "key": "created",                                                                                                    // 413
  "fr": "créé",                                                                                                        // 414
  "en": "created"                                                                                                      // 415
}, {                                                                                                                   // 412
  "key": "actions",                                                                                                    // 418
  "fr": "actions",                                                                                                     // 419
  "en": "actions"                                                                                                      // 420
}, {                                                                                                                   // 417
  "key": "archive",                                                                                                    // 423
  "fr": "archiver",                                                                                                    // 424
  "en": "archive"                                                                                                      // 425
}, {                                                                                                                   // 422
  "key": "my-drawings",                                                                                                // 428
  "fr": "mes dessins",                                                                                                 // 429
  "en": "my drawings"                                                                                                  // 430
}, {                                                                                                                   // 427
  "key": "dataroom",                                                                                                   // 433
  "fr": "fichiers",                                                                                                    // 434
  "en": "dataroom"                                                                                                     // 435
}, {                                                                                                                   // 432
  "key": "drawings",                                                                                                   // 438
  "fr": "dessins",                                                                                                     // 439
  "en": "drawings"                                                                                                     // 440
}, {                                                                                                                   // 437
  "key": "no-chat-selected",                                                                                           // 443
  "fr": "aucun chat séléctionné",                                                                                      // 444
  "en": "no chat selected"                                                                                             // 445
}, {                                                                                                                   // 442
  "key": "shared",                                                                                                     // 448
  "fr": "partagé",                                                                                                     // 449
  "en": "shared"                                                                                                       // 450
}, {                                                                                                                   // 447
  "key": "open-dataroom",                                                                                              // 453
  "fr": "ouvrir le partage de fichiers",                                                                               // 454
  "en": "open files sharing"                                                                                           // 455
}, {                                                                                                                   // 452
  "key": "share",                                                                                                      // 458
  "fr": "partage",                                                                                                     // 459
  "en": "share"                                                                                                        // 460
}, {                                                                                                                   // 457
  "key": "reset",                                                                                                      // 463
  "fr": "réinitialiser",                                                                                               // 464
  "en": "reset"                                                                                                        // 465
}, {                                                                                                                   // 462
  "key": "me",                                                                                                         // 468
  "fr": "moi",                                                                                                         // 469
  "en": "me"                                                                                                           // 470
}, {                                                                                                                   // 467
  "key": "roll-dices",                                                                                                 // 473
  "fr": "lancer de dés",                                                                                               // 474
  "en": "roll dices"                                                                                                   // 475
}, {                                                                                                                   // 472
  "key": "rolls-history",                                                                                              // 478
  "fr": "historique des lancers",                                                                                      // 479
  "en": "rolls history"                                                                                                // 480
}, {                                                                                                                   // 477
  "key": "result",                                                                                                     // 483
  "fr": "résultat",                                                                                                    // 484
  "en": "result"                                                                                                       // 485
}, {                                                                                                                   // 482
  "key": "reset-inferface-confirm",                                                                                    // 488
  "fr": "ceci réinitialisera l'interface, veuillez confirmer l'action",                                                // 489
  "en": "this will reset the interface, please confirm action"                                                         // 490
}, {                                                                                                                   // 487
  "key": "reset-interface",                                                                                            // 493
  "fr": "réinitialiser l'inferface",                                                                                   // 494
  "en": "reset interface"                                                                                              // 495
}, {                                                                                                                   // 492
  "key": "lock-interface",                                                                                             // 498
  "fr": "vérouiller l'inferface",                                                                                      // 499
  "en": "lock interface"                                                                                               // 500
}, {                                                                                                                   // 497
  "key": "unlock-interface",                                                                                           // 503
  "fr": "dévérouiller l'inferface",                                                                                    // 504
  "en": "unlock interface"                                                                                             // 505
}, {                                                                                                                   // 502
  "key": "dice",                                                                                                       // 508
  "fr": "dé",                                                                                                          // 509
  "en": "dice"                                                                                                         // 510
}, {                                                                                                                   // 507
  "key": "save",                                                                                                       // 513
  "fr": "enregistrer",                                                                                                 // 514
  "en": "save"                                                                                                         // 515
}, {                                                                                                                   // 512
  "key": "title",                                                                                                      // 518
  "fr": "titre",                                                                                                       // 519
  "en": "title"                                                                                                        // 520
}, {                                                                                                                   // 517
  "key": "new-drawing",                                                                                                // 523
  "fr": "nouveau dessin",                                                                                              // 524
  "en": "new drawing"                                                                                                  // 525
}, {                                                                                                                   // 522
  "key": "opened-drawing",                                                                                             // 528
  "fr": "dessin ouvert",                                                                                               // 529
  "en": "opened drawing"                                                                                               // 530
}, {                                                                                                                   // 527
  "key": "shared-drawings",                                                                                            // 533
  "fr": "dessins partagés ( avec moi )",                                                                               // 534
  "en": "shared drawings ( with me )"                                                                                  // 535
}, {                                                                                                                   // 532
  "key": "set-game-open",                                                                                              // 538
  "fr": "passer le jeu de rôle à \"\ouvert\" ( les nouveaux joueurs peuvent rejoindre )",                              // 539
  "en": "set the rpg to \"open\" ( new players can join )"                                                             // 540
}, {                                                                                                                   // 537
  "key": "set-game-closed",                                                                                            // 543
  "fr": "passer le jeu de rôle à \"fermé\" ( les nouveaux joueurs ne peuvent pas rejoindre )",                         // 544
  "en": "set the rpg to \"closed\" ( new players can not join )"                                                       // 545
}, {                                                                                                                   // 542
  "key": "select-model-sheet",                                                                                         // 548
  "fr": "séléctionner un modèle de feuille",                                                                           // 549
  "en": "select a model sheet"                                                                                         // 550
}, {                                                                                                                   // 547
  "key": "archived-only",                                                                                              // 553
  "fr": "uniquement les archives",                                                                                     // 554
  "en": "archived only"                                                                                                // 555
}, {                                                                                                                   // 552
  "key": "click-to-change-avatar",                                                                                     // 558
  "fr": "cliquez pour changer votre avatar",                                                                           // 559
  "en": "click to change your avatar"                                                                                  // 560
}, {                                                                                                                   // 557
  "key": "open-my-sheet",                                                                                              // 563
  "fr": "ouvrir ma feuille de personnage",                                                                             // 564
  "en": "open my character sheet"                                                                                      // 565
}, {                                                                                                                   // 562
  "key": "open-sheet",                                                                                                 // 568
  "fr": "ouvrir la feuille de personnage",                                                                             // 569
  "en": "open character sheet"                                                                                         // 570
}, {                                                                                                                   // 567
  "key": "sheet-lock",                                                                                                 // 573
  "fr": "feuille vérouillée",                                                                                          // 574
  "en": "sheet is locked"                                                                                              // 575
}, {                                                                                                                   // 572
  "key": "unlock-sheet",                                                                                               // 578
  "fr": "dévérouiller la feuille",                                                                                     // 579
  "en": "unlock sheet"                                                                                                 // 580
}, {                                                                                                                   // 577
  "key": "sheet-unlock",                                                                                               // 583
  "fr": "feuille dévérouillée",                                                                                        // 584
  "en": "sheet is unlocked"                                                                                            // 585
}, {                                                                                                                   // 582
  "key": "lock-sheet",                                                                                                 // 588
  "fr": "vérouiller la feuille",                                                                                       // 589
  "en": "lock sheet"                                                                                                   // 590
}, {                                                                                                                   // 587
  "key": "undo",                                                                                                       // 593
  "fr": "annuler",                                                                                                     // 594
  "en": "undo"                                                                                                         // 595
}, {                                                                                                                   // 592
  "key": "pnj",                                                                                                        // 598
  "fr": "pnj",                                                                                                         // 599
  "en": "npc"                                                                                                          // 600
}, {                                                                                                                   // 597
  "key": "pnjs",                                                                                                       // 603
  "fr": "PNJs",                                                                                                        // 604
  "en": "NPCs"                                                                                                         // 605
}, {                                                                                                                   // 602
  "key": "add-pnj",                                                                                                    // 608
  "fr": "ajouter pnj",                                                                                                 // 609
  "en": "add npc"                                                                                                      // 610
}, {                                                                                                                   // 607
  "key": "no-drawing",                                                                                                 // 613
  "fr": "pas de dessin",                                                                                               // 614
  "en": "no drawing"                                                                                                   // 615
}, {                                                                                                                   // 612
  "key": "clone",                                                                                                      // 618
  "fr": "cloner",                                                                                                      // 619
  "en": "clone"                                                                                                        // 620
}, {                                                                                                                   // 617
  "key": "my-modelsheets",                                                                                             // 623
  "fr": "mes modèles de feuilles",                                                                                     // 624
  "en": "my model sheets"                                                                                              // 625
}, {                                                                                                                   // 622
  "key": "public-modelsheets",                                                                                         // 628
  "fr": "modèles de feuilles publiques ( partagés )",                                                                  // 629
  "en": "public model sheets ( shared )"                                                                               // 630
}, {                                                                                                                   // 627
  "key": "copy-modelsheets-done",                                                                                      // 633
  "fr": "copie du modèle terminé, retrouvez le dans l'onglet mes modèles",                                             // 634
  "en": "copy terminated, the model is in my model sheets tab"                                                         // 635
}, {                                                                                                                   // 632
  "key": "model-sheet-limit",                                                                                          // 638
  "fr": "limite de modèles de feuilles atteint ( 50 modèles max )",                                                    // 639
  "en": "you have reach the limit of model sheet number ( 50 models max )"                                             // 640
}, {                                                                                                                   // 637
  "key": "model-sheet-limit-info",                                                                                     // 643
  "fr": "vous pouvez posséder un maximum de 50 modèles de feuilles",                                                   // 644
  "en": "you can have a maximum of 50 model sheets"                                                                    // 645
}, {                                                                                                                   // 642
  "key": "open-games-info",                                                                                            // 648
  "fr": "les jeux fermés ne peuvent être rejoins que par les joueurs qui sont déjà dans la partie",                    // 649
  "en": "closed games can only be joined by player who are already in the game"                                        // 650
}, {                                                                                                                   // 647
  "key": "drawings-saved-info",                                                                                        // 653
  "fr": "votre dessin à été sauvé, retrouvez le dans l'onglet \"mes dessins\"",                                        // 654
  "en": "your drawing has been saved, you can see and share it from \"my drawings\" tab"                               // 655
}];                                                                                                                    // 652
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"chats.js":["meteor/meteor","meteor/mongo","meteor/check","./rpgs.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/chats.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({Chats:function(){return Chats}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Rpgs;module.import('./rpgs.js',{"Rpgs":function(v){Rpgs=v}});
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       // 4
                                                                                                                       //
var Chats = new Mongo.Collection('chats');                                                                             // 6
                                                                                                                       //
var ChatUser = new SimpleSchema({                                                                                      // 8
	owner: { type: String },                                                                                              // 9
	username: { type: String },                                                                                           // 10
	unread: { type: Number }                                                                                              // 11
});                                                                                                                    // 8
                                                                                                                       //
var ChatMessage = new SimpleSchema({                                                                                   // 14
	content: { type: String },                                                                                            // 15
	owner: { type: String },                                                                                              // 16
	username: { type: String },                                                                                           // 17
	date: { type: String }                                                                                                // 18
});                                                                                                                    // 14
                                                                                                                       //
Chats.schema = new SimpleSchema({                                                                                      // 21
	_id: { type: String, optional: true },                                                                                // 22
	rpg: { type: String },                                                                                                // 23
	name: { type: String }, // nom du chat                                                                                // 24
	users: { type: [ChatUser] },                                                                                          // 25
	messages: { type: [ChatMessage] },                                                                                    // 26
	type: { type: String } // all-players or other                                                                        // 27
});                                                                                                                    // 21
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 30
	Meteor.publish('chats.rpg', function () {                                                                             // 31
		function chatRpgPublication(rpgId) {                                                                                 // 31
			var rpg = Rpgs.findOne(rpgId);                                                                                      // 32
			if (rpg.roleMaster === this.userId) {                                                                               // 33
				// role Master can see all chats                                                                                   // 34
				return Chats.find({ rpg: rpgId });                                                                                 // 35
			}                                                                                                                   // 36
			return Chats.find({                                                                                                 // 37
				'rpg': rpgId,                                                                                                      // 38
				'users.owner': this.userId                                                                                         // 39
			});                                                                                                                 // 37
		}                                                                                                                    // 41
                                                                                                                       //
		return chatRpgPublication;                                                                                           // 31
	}());                                                                                                                 // 31
}                                                                                                                      // 42
                                                                                                                       //
Meteor.methods({                                                                                                       // 44
	'chats.insertMessage': function () {                                                                                  // 45
		function chatsInsertMessage(id, content) {                                                                           // 44
			var _this = this;                                                                                                   // 45
                                                                                                                       //
			check(id, String);                                                                                                  // 46
			check(content, String);                                                                                             // 47
                                                                                                                       //
			if (!content.length) {                                                                                              // 49
				return;                                                                                                            // 50
			}                                                                                                                   // 51
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 53
				throw new Meteor.Error('not-authorized');                                                                          // 54
			}                                                                                                                   // 55
                                                                                                                       //
			var chat = Chats.findOne(id);                                                                                       // 57
			var users = [];                                                                                                     // 58
			chat.users.forEach(function (u) {                                                                                   // 59
				if (u.owner !== _this.userId) {                                                                                    // 60
					u.unread++;                                                                                                       // 61
				}                                                                                                                  // 62
				users.push(u);                                                                                                     // 63
			});                                                                                                                 // 64
                                                                                                                       //
			Chats.update(id, {                                                                                                  // 66
				$push: {                                                                                                           // 67
					messages: {                                                                                                       // 68
						content: content,                                                                                                // 69
						owner: this.userId,                                                                                              // 70
						username: Meteor.users.findOne(this.userId).username,                                                            // 71
						date: new Date()                                                                                                 // 72
					}                                                                                                                 // 68
				},                                                                                                                 // 67
				$set: {                                                                                                            // 75
					'users': users                                                                                                    // 76
				}                                                                                                                  // 75
			});                                                                                                                 // 66
		}                                                                                                                    // 79
                                                                                                                       //
		return chatsInsertMessage;                                                                                           // 44
	}(),                                                                                                                  // 44
	'chats.setRead': function () {                                                                                        // 80
		function chatsSetRead(id) {                                                                                          // 44
			var _this2 = this;                                                                                                  // 80
                                                                                                                       //
			check(id, String);                                                                                                  // 81
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 83
				throw new Meteor.Error('not-authorized');                                                                          // 84
			}                                                                                                                   // 85
                                                                                                                       //
			var chat = Chats.findOne(id);                                                                                       // 87
			var set = {};                                                                                                       // 88
			chat.users.some(function (u, i) {                                                                                   // 89
				if (u.owner === _this2.userId) {                                                                                   // 90
					set['users.' + i + '.unread'] = 0;                                                                                // 91
					return true;                                                                                                      // 92
				}                                                                                                                  // 93
				return false;                                                                                                      // 94
			});                                                                                                                 // 95
                                                                                                                       //
			Chats.update(id, {                                                                                                  // 97
				$set: set                                                                                                          // 98
			});                                                                                                                 // 97
		}                                                                                                                    // 100
                                                                                                                       //
		return chatsSetRead;                                                                                                 // 44
	}()                                                                                                                   // 44
});                                                                                                                    // 44
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"drawings.js":["meteor/meteor","meteor/mongo","meteor/check",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/drawings.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({Drawings:function(){return Drawings}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
var Drawings = new Mongo.Collection('drawings');                                                                       // 5
                                                                                                                       //
var UserShare = new SimpleSchema({                                                                                     // 7
	owner: { type: String },                                                                                              // 8
	username: { type: String }                                                                                            // 9
});                                                                                                                    // 7
                                                                                                                       //
Drawings.schema = new SimpleSchema({                                                                                   // 12
	_id: { type: String, optional: true },                                                                                // 13
	owner: { type: String },                                                                                              // 14
	username: { type: String },                                                                                           // 15
	sharedTo: { type: [UserShare] }, // ids of users                                                                      // 16
	rpg: { type: String }, // which rpg                                                                                   // 17
	data: { type: String }, // json str representing drawing                                                              // 18
	title: { type: String },                                                                                              // 19
	createdAt: { type: Date }                                                                                             // 20
});                                                                                                                    // 12
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 23
	Meteor.publish('drawings.rpg', function () {                                                                          // 24
		function drawingsPublication(rpgId) {                                                                                // 24
			return Drawings.find({                                                                                              // 25
				rpg: rpgId,                                                                                                        // 26
				$or: [{                                                                                                            // 27
					owner: this.userId                                                                                                // 29
				}, {                                                                                                               // 28
					'sharedTo.owner': this.userId                                                                                     // 32
				}]                                                                                                                 // 31
			}, {                                                                                                                // 25
				fields: {                                                                                                          // 36
					data: -1,                                                                                                         // 37
					owner: 1,                                                                                                         // 38
					username: 1,                                                                                                      // 39
					sharedTo: 1,                                                                                                      // 40
					rpg: 1,                                                                                                           // 41
					title: 1,                                                                                                         // 42
					createdAt: 1                                                                                                      // 43
				}                                                                                                                  // 36
			});                                                                                                                 // 35
		}                                                                                                                    // 46
                                                                                                                       //
		return drawingsPublication;                                                                                          // 24
	}());                                                                                                                 // 24
}                                                                                                                      // 47
                                                                                                                       //
Meteor.methods({                                                                                                       // 49
	'drawings.insert': function () {                                                                                      // 50
		function drawingsInsert(rpgId, title, data, sharedIds) {                                                             // 49
			check(rpgId, String);                                                                                               // 51
			check(data, String);                                                                                                // 52
			check(title, String);                                                                                               // 53
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 55
				throw new Meteor.Error('not-authorized');                                                                          // 56
			}                                                                                                                   // 57
                                                                                                                       //
			if (data.length < 100) {                                                                                            // 59
				return;                                                                                                            // 60
			}                                                                                                                   // 61
                                                                                                                       //
			var drawingsCount = Drawings.find({ rpg: rpgId, owner: this.userId }).count(); // 10 by rpg                         // 63
			if (drawingsCount >= 10) {                                                                                          // 64
				throw new Meteor.Error('not-authorized');                                                                          // 65
			}                                                                                                                   // 66
                                                                                                                       //
			var sharedTo = [];                                                                                                  // 68
			if (Meteor.isServer) {                                                                                              // 69
				var sharedUsers = Meteor.users.find({ _id: { $in: sharedIds } });                                                  // 70
				sharedUsers.forEach(function (u) {                                                                                 // 71
					sharedTo.push({                                                                                                   // 72
						owner: u._id,                                                                                                    // 73
						username: u.username                                                                                             // 74
					});                                                                                                               // 72
				});                                                                                                                // 76
			}                                                                                                                   // 77
                                                                                                                       //
			var drawing = {                                                                                                     // 79
				owner: this.userId,                                                                                                // 80
				username: Meteor.users.findOne(this.userId).username,                                                              // 81
				sharedTo: sharedTo,                                                                                                // 82
				rpg: rpgId,                                                                                                        // 83
				data: data,                                                                                                        // 84
				title: title,                                                                                                      // 85
				createdAt: new Date()                                                                                              // 86
			};                                                                                                                  // 79
                                                                                                                       //
			Drawings.schema.validate(drawing);                                                                                  // 89
			Drawings.insert(drawing);                                                                                           // 90
		}                                                                                                                    // 91
                                                                                                                       //
		return drawingsInsert;                                                                                               // 49
	}(),                                                                                                                  // 49
	'drawings.remove': function () {                                                                                      // 92
		function drawingsRemove(id) {                                                                                        // 49
			check(id, String);                                                                                                  // 93
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 95
				throw new Meteor.Error('not-authorized');                                                                          // 96
			}                                                                                                                   // 97
			Drawings.remove({ _id: id, owner: this.userId });                                                                   // 98
		}                                                                                                                    // 99
                                                                                                                       //
		return drawingsRemove;                                                                                               // 49
	}(),                                                                                                                  // 49
	'drawings.setShared': function () {                                                                                   // 100
		function drawingsSetShared(id, userId) {                                                                             // 49
			check(id, String);                                                                                                  // 101
			check(userId, String);                                                                                              // 102
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 104
				throw new Meteor.Error('not-authorized');                                                                          // 105
			}                                                                                                                   // 106
                                                                                                                       //
			var drawing = Drawings.findOne({ owner: this.userId, _id: id });                                                    // 108
                                                                                                                       //
			if (!drawing) {                                                                                                     // 110
				throw new Meteor.Error('not-authorized');                                                                          // 111
			}                                                                                                                   // 112
			var indexRemove = -1;                                                                                               // 113
			drawing.sharedTo.some(function (u, i) {                                                                             // 114
				if (u.owner === userId) {                                                                                          // 115
					indexRemove = i;                                                                                                  // 116
					return true;                                                                                                      // 117
				}                                                                                                                  // 118
			});                                                                                                                 // 119
			if (indexRemove === -1) {                                                                                           // 120
				//push                                                                                                             // 121
				drawing.sharedTo.push({                                                                                            // 122
					owner: userId,                                                                                                    // 123
					username: Meteor.users.findOne(userId)                                                                            // 124
				});                                                                                                                // 122
			} else {                                                                                                            // 126
				//spliced                                                                                                          // 127
				drawing.sharedTo.splice(indexRemove, 1);                                                                           // 128
			}                                                                                                                   // 129
			//update                                                                                                            // 130
			Drawings.update(id, {                                                                                               // 131
				$set: {                                                                                                            // 132
					sharedTo: drawing.sharedTo                                                                                        // 133
				}                                                                                                                  // 132
			});                                                                                                                 // 131
		}                                                                                                                    // 136
                                                                                                                       //
		return drawingsSetShared;                                                                                            // 49
	}(),                                                                                                                  // 49
	'drawings.getWithData': function () {                                                                                 // 137
		function drawingsGetWithData(id) {                                                                                   // 49
			var _this = this;                                                                                                   // 137
                                                                                                                       //
			check(id, String);                                                                                                  // 138
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 140
				throw new Meteor.Error('not-authorized');                                                                          // 141
			}                                                                                                                   // 142
                                                                                                                       //
			if (Meteor.isServer) {                                                                                              // 144
				var drawing = Drawings.findOne(id);                                                                                // 145
				if (drawing.owner === this.userId || drawing.sharedTo.find(function (u) {                                          // 146
					return u.owner === _this.userId;                                                                                  // 146
				})) {                                                                                                              // 146
					return drawing;                                                                                                   // 147
				} else {                                                                                                           // 148
					throw new Meteor.Error('not-authorized');                                                                         // 149
				}                                                                                                                  // 150
			}                                                                                                                   // 151
		}                                                                                                                    // 152
                                                                                                                       //
		return drawingsGetWithData;                                                                                          // 49
	}(),                                                                                                                  // 49
	'drawings.update': function () {                                                                                      // 153
		function drawingsUpdate(id, title, data, sharedIds) {                                                                // 49
			check(id, String);                                                                                                  // 154
			check(title, String);                                                                                               // 155
			check(data, String);                                                                                                // 156
			check(sharedIds, Array);                                                                                            // 157
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 159
				throw new Meteor.Error('not-authorized');                                                                          // 160
			}                                                                                                                   // 161
                                                                                                                       //
			if (Meteor.isServer) {                                                                                              // 163
				var drawing = Drawings.findOne(id);                                                                                // 164
				if (drawing.owner !== this.userId) {                                                                               // 165
					throw new Meteor.Error('not-authorized');                                                                         // 166
				} else {                                                                                                           // 167
					(function () {                                                                                                    // 167
						var sharedTo = [];                                                                                               // 168
						var sharedUsers = Meteor.users.find({ _id: { $in: sharedIds } });                                                // 169
						sharedUsers.forEach(function (u) {                                                                               // 170
							sharedTo.push({                                                                                                 // 171
								owner: u._id,                                                                                                  // 172
								username: u.username                                                                                           // 173
							});                                                                                                             // 171
						});                                                                                                              // 175
						Drawings.update(id, {                                                                                            // 176
							$set: {                                                                                                         // 177
								title: title,                                                                                                  // 178
								data: data,                                                                                                    // 179
								sharedTo: sharedTo                                                                                             // 180
							}                                                                                                               // 177
						});                                                                                                              // 176
					})();                                                                                                             // 167
				}                                                                                                                  // 183
			}                                                                                                                   // 184
		}                                                                                                                    // 185
                                                                                                                       //
		return drawingsUpdate;                                                                                               // 49
	}(),                                                                                                                  // 49
	'drawings.publicImgs': function () {                                                                                  // 186
		function drawingsPublicImgs() {                                                                                      // 49
			if (Meteor.isServer) {                                                                                              // 187
				var fs = Npm.require("fs");                                                                                        // 188
				var dessinsPath = process.env.PWD + '/public/images/dessins/';                                                     // 189
				return fs.readdirSync(dessinsPath);                                                                                // 190
			}                                                                                                                   // 191
		}                                                                                                                    // 192
                                                                                                                       //
		return drawingsPublicImgs;                                                                                           // 49
	}()                                                                                                                   // 49
});                                                                                                                    // 49
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"model-sheets.js":["meteor/meteor","meteor/mongo","meteor/check",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/model-sheets.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({ModelSheets:function(){return ModelSheets},TableElementSchema:function(){return TableElementSchema},ElementSchema:function(){return ElementSchema},SectionSchema:function(){return SectionSchema}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
var ModelSheets = new Mongo.Collection('modelsheets');                                                                 // 5
                                                                                                                       //
/* Simple schemas */                                                                                                   // 7
// element.table.case                                                                                                  // 8
// element.table.case                                                                                                  // 9
                                                                                                                       //
// element.table                                                                                                       // 11
var TableElementSchema = new SimpleSchema({                                                                            // 12
  rows: { type: Number },                                                                                              // 13
  cols: { type: Number },                                                                                              // 14
  cases: { type: { Object: Object } }                                                                                  // 15
});                                                                                                                    // 12
                                                                                                                       //
// element                                                                                                             // 18
var ElementSchema = new SimpleSchema({                                                                                 // 19
  label: { type: String },                                                                                             // 20
  table: { type: TableElementSchema, optional: true },                                                                 // 21
  id: { type: String },                                                                                                // 22
  type: { type: String }                                                                                               // 23
});                                                                                                                    // 19
                                                                                                                       //
var SectionSchema = new SimpleSchema({                                                                                 // 26
  id: { type: String },                                                                                                // 27
  name: { type: String },                                                                                              // 28
  elements: { type: [ElementSchema], optional: true },                                                                 // 29
  size: { type: Number, optional: true },                                                                              // 30
  isSeparator: { type: Boolean, optional: true }                                                                       // 31
});                                                                                                                    // 26
                                                                                                                       //
// model sheet schema                                                                                                  // 34
ModelSheets.schema = new SimpleSchema({                                                                                // 35
  _id: { type: String, optional: true },                                                                               // 36
  name: { type: String, max: 40, min: 1 },                                                                             // 37
  createdAt: { type: Date },                                                                                           // 38
  owner: { type: String },                                                                                             // 39
  username: { type: String },                                                                                          // 40
  'private': { type: Boolean },                                                                                        // 41
  sections: { type: [SectionSchema], optional: true },                                                                 // 42
  language: { type: String }                                                                                           // 43
});                                                                                                                    // 35
                                                                                                                       //
// publications                                                                                                        // 46
if (Meteor.isServer) {                                                                                                 // 47
  // This code only runs on the server                                                                                 // 48
  Meteor.publish('modelsheets', function () {                                                                          // 49
    function ModelSheetsPublication() {                                                                                // 49
      return ModelSheets.find({                                                                                        // 50
        $or: [{ owner: this.userId }, { 'private': false }]                                                            // 51
      });                                                                                                              // 50
    }                                                                                                                  // 56
                                                                                                                       //
    return ModelSheetsPublication;                                                                                     // 49
  }());                                                                                                                // 49
                                                                                                                       //
  Meteor.publish('modelsheet', function () {                                                                           // 58
    function ModelSheetPublication(id) {                                                                               // 58
      return ModelSheets.find({                                                                                        // 59
        _id: id,                                                                                                       // 60
        $or: [{ owner: this.userId }, { 'private': false }]                                                            // 61
      });                                                                                                              // 59
    }                                                                                                                  // 66
                                                                                                                       //
    return ModelSheetPublication;                                                                                      // 58
  }());                                                                                                                // 58
                                                                                                                       //
  Meteor.publish('modelsheets.search', function () {                                                                   // 68
    function ModelSheetPublication(search) {                                                                           // 68
      return ModelSheets.find({                                                                                        // 69
        name: new RegExp(search, 'i'),                                                                                 // 70
        $or: [{ owner: this.userId }, { 'private': false }]                                                            // 71
      });                                                                                                              // 69
    }                                                                                                                  // 76
                                                                                                                       //
    return ModelSheetPublication;                                                                                      // 68
  }());                                                                                                                // 68
}                                                                                                                      // 77
                                                                                                                       //
Meteor.methods({                                                                                                       // 79
  'modelsheets.insert': function () {                                                                                  // 80
    function modelsheetsInsert(name, language) {                                                                       // 79
      var jsonStr = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';                            // 80
                                                                                                                       //
      check(name, String);                                                                                             // 81
      check(language, String);                                                                                         // 82
      check(jsonStr, String);                                                                                          // 83
                                                                                                                       //
      if (!this.userId) {                                                                                              // 85
        throw new Meteor.Error('not-authorized');                                                                      // 86
      }                                                                                                                // 87
                                                                                                                       //
      var n = ModelSheets.find({ owner: this.userId }).count();                                                        // 89
      if (n >= 50) {                                                                                                   // 90
        throw new Meteor.Error('not-authorized');                                                                      // 91
      }                                                                                                                // 92
                                                                                                                       //
      var sections = [];                                                                                               // 94
      if (jsonStr.length) {                                                                                            // 95
        try {                                                                                                          // 96
          sections = JSON.parse(jsonStr).sections;                                                                     // 97
        } catch (e) {                                                                                                  // 98
          console.log(e);                                                                                              // 99
          sections = [];                                                                                               // 100
        }                                                                                                              // 101
      }                                                                                                                // 102
                                                                                                                       //
      var model = {                                                                                                    // 104
        name: name,                                                                                                    // 105
        createdAt: new Date(),                                                                                         // 106
        owner: this.userId,                                                                                            // 107
        username: Meteor.users.findOne(this.userId).username,                                                          // 108
        'private': true,                                                                                               // 109
        sections: [],                                                                                                  // 110
        language: language                                                                                             // 111
      };                                                                                                               // 104
                                                                                                                       //
      ModelSheets.schema.validate(model);                                                                              // 114
      model.sections = sections;                                                                                       // 115
      ModelSheets.insert(model);                                                                                       // 116
    }                                                                                                                  // 117
                                                                                                                       //
    return modelsheetsInsert;                                                                                          // 79
  }(),                                                                                                                 // 79
  'modelsheets.update': function () {                                                                                  // 118
    function modelsheetsUpdate(modelSheetId, name, language, isPrivate) {                                              // 79
      check(modelSheetId, String);                                                                                     // 119
      check(name, String);                                                                                             // 120
                                                                                                                       //
      if (!this.userId) {                                                                                              // 123
        throw new Meteor.Error('not-authorized');                                                                      // 124
      }                                                                                                                // 125
      var model = ModelSheets.findOne(modelSheetId);                                                                   // 126
      if (!model) {                                                                                                    // 127
        throw new Meteor.Error('not-found');                                                                           // 128
      }                                                                                                                // 129
      if (model.owner !== this.userId) {                                                                               // 130
        throw new Meteor.Error('not-authorized');                                                                      // 131
      }                                                                                                                // 132
      if (!language) {                                                                                                 // 133
        language = model.language;                                                                                     // 134
        isPrivate = model['private'];                                                                                  // 135
      }                                                                                                                // 136
      ModelSheets.update(modelSheetId, {                                                                               // 137
        $set: {                                                                                                        // 138
          name: name,                                                                                                  // 139
          'private': isPrivate,                                                                                        // 140
          language: language                                                                                           // 141
        }                                                                                                              // 138
      });                                                                                                              // 137
    }                                                                                                                  // 144
                                                                                                                       //
    return modelsheetsUpdate;                                                                                          // 79
  }(),                                                                                                                 // 79
  'modelsheets.remove': function () {                                                                                  // 145
    function modelsheetsRemove(modelSheetId) {                                                                         // 79
      check(modelSheetId, String);                                                                                     // 146
      if (!this.userId) {                                                                                              // 147
        throw new Meteor.Error('not-authorized');                                                                      // 148
      }                                                                                                                // 149
      var model = ModelSheets.findOne(modelSheetId);                                                                   // 150
      if (!model) {                                                                                                    // 151
        throw new Meteor.Error('not-found');                                                                           // 152
      }                                                                                                                // 153
      if (model.owner !== this.userId) {                                                                               // 154
        throw new Meteor.Error('not-authorized');                                                                      // 155
      }                                                                                                                // 156
      ModelSheets.remove(modelSheetId);                                                                                // 157
    }                                                                                                                  // 158
                                                                                                                       //
    return modelsheetsRemove;                                                                                          // 79
  }(),                                                                                                                 // 79
  'modelsheets.removeSection': function () {                                                                           // 159
    function modelsheetsRemoveSection(modelSheetId, sectionId) {                                                       // 79
      check(modelSheetId, String);                                                                                     // 160
      check(sectionId, String);                                                                                        // 161
                                                                                                                       //
      if (!this.userId) {                                                                                              // 163
        throw new Meteor.Error('not-authorized');                                                                      // 164
      }                                                                                                                // 165
      var model = ModelSheets.findOne(modelSheetId);                                                                   // 166
      if (!model) {                                                                                                    // 167
        throw new Meteor.Error('not-found');                                                                           // 168
      }                                                                                                                // 169
      if (model.owner !== this.userId) {                                                                               // 170
        throw new Meteor.Error('not-authorized');                                                                      // 171
      }                                                                                                                // 172
      model.sections.forEach(function (s, i) {                                                                         // 173
        if (s.id === sectionId) {                                                                                      // 174
          model.sections.splice(i, 1);                                                                                 // 175
        }                                                                                                              // 176
      });                                                                                                              // 177
      ModelSheets.update(modelSheetId, {                                                                               // 178
        $set: {                                                                                                        // 179
          sections: model.sections                                                                                     // 180
        }                                                                                                              // 179
      });                                                                                                              // 178
    }                                                                                                                  // 183
                                                                                                                       //
    return modelsheetsRemoveSection;                                                                                   // 79
  }(),                                                                                                                 // 79
  'modelsheets.updateSection': function () {                                                                           // 184
    function modelsheetsUpdateSection(modelSheetId, sectionId, name, size) {                                           // 79
      check(modelSheetId, String);                                                                                     // 185
      check(sectionId, String);                                                                                        // 186
      check(name, String);                                                                                             // 187
      check(size, Number);                                                                                             // 188
                                                                                                                       //
      if (!this.userId) {                                                                                              // 190
        throw new Meteor.Error('not-authorized');                                                                      // 191
      }                                                                                                                // 192
      var model = ModelSheets.findOne(modelSheetId);                                                                   // 193
      if (!model) {                                                                                                    // 194
        throw new Meteor.Error('not-found');                                                                           // 195
      }                                                                                                                // 196
      if (model.owner !== this.userId) {                                                                               // 197
        throw new Meteor.Error('not-authorized');                                                                      // 198
      }                                                                                                                // 199
      var set = {};                                                                                                    // 200
      model.sections.some(function (s, i) {                                                                            // 201
        if (s.id === sectionId) {                                                                                      // 202
          set['sections.' + i + '.name'] = name;                                                                       // 203
          set['sections.' + i + '.size'] = size;                                                                       // 204
          return true;                                                                                                 // 205
        }                                                                                                              // 206
      });                                                                                                              // 207
      // update                                                                                                        // 208
      ModelSheets.update(modelSheetId, {                                                                               // 209
        $set: set                                                                                                      // 210
      });                                                                                                              // 209
    }                                                                                                                  // 212
                                                                                                                       //
    return modelsheetsUpdateSection;                                                                                   // 79
  }(),                                                                                                                 // 79
  'modelsheets.addElement': function () {                                                                              // 213
    function modelsheetsAddElement(modelSheetId, elementType, sectionId) {                                             // 79
      var sectionSize = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : -1;                        // 213
                                                                                                                       //
      check(modelSheetId, String);                                                                                     // 214
      check(elementType, String);                                                                                      // 215
      check(sectionId, String);                                                                                        // 216
      check(sectionSize, Number);                                                                                      // 217
                                                                                                                       //
      if (!this.userId) {                                                                                              // 219
        throw new Meteor.Error('not-authorized');                                                                      // 220
      }                                                                                                                // 221
      var model = ModelSheets.findOne(modelSheetId);                                                                   // 222
      if (!model) {                                                                                                    // 223
        throw new Meteor.Error('not-found');                                                                           // 224
      }                                                                                                                // 225
      if (model.owner !== this.userId) {                                                                               // 226
        throw new Meteor.Error('not-authorized');                                                                      // 227
      }                                                                                                                // 228
                                                                                                                       //
      var element = {                                                                                                  // 230
        id: Random.id(),                                                                                               // 231
        type: elementType,                                                                                             // 232
        label: ''                                                                                                      // 233
      };                                                                                                               // 230
                                                                                                                       //
      if (sectionId === 'new') {                                                                                       // 236
        ModelSheets.update(modelSheetId, {                                                                             // 237
          $push: {                                                                                                     // 238
            sections: {                                                                                                // 239
              id: Random.id(),                                                                                         // 240
              name: '',                                                                                                // 241
              size: sectionSize,                                                                                       // 242
              elements: [element]                                                                                      // 243
            }                                                                                                          // 239
          }                                                                                                            // 238
        });                                                                                                            // 237
      } else {                                                                                                         // 247
        (function () {                                                                                                 // 247
                                                                                                                       //
          var sheet = ModelSheets.findOne(modelSheetId);                                                               // 249
          var set = {};                                                                                                // 250
          sheet.sections.forEach(function (s, i) {                                                                     // 251
            if (s.id === sectionId) {                                                                                  // 252
              s.elements.push(element);                                                                                // 253
              set['sections.' + i] = s;                                                                                // 254
            }                                                                                                          // 255
          });                                                                                                          // 256
          ModelSheets.update(modelSheetId, {                                                                           // 257
            $set: set                                                                                                  // 258
          });                                                                                                          // 257
        })();                                                                                                          // 247
      }                                                                                                                // 260
    }                                                                                                                  // 261
                                                                                                                       //
    return modelsheetsAddElement;                                                                                      // 79
  }(),                                                                                                                 // 79
  'modelsheets.removeElement': function () {                                                                           // 262
    function modelsheetsRemoveElement(id, elementId) {                                                                 // 79
      check(id, String);                                                                                               // 263
      check(elementId, String);                                                                                        // 264
                                                                                                                       //
      if (!this.userId) {                                                                                              // 266
        throw new Meteor.Error('not-authorized');                                                                      // 267
      }                                                                                                                // 268
      var model = ModelSheets.findOne(id);                                                                             // 269
      if (!model) {                                                                                                    // 270
        throw new Meteor.Error('not-found');                                                                           // 271
      }                                                                                                                // 272
      if (model.owner !== this.userId) {                                                                               // 273
        throw new Meteor.Error('not-authorized');                                                                      // 274
      }                                                                                                                // 275
      var set = {};                                                                                                    // 276
      model.sections.some(function (s, i) {                                                                            // 277
        return s.elements.some(function (e, j) {                                                                       // 278
          if (e.id === elementId) {                                                                                    // 279
            var section = s;                                                                                           // 280
            section.elements.splice(j, 1);                                                                             // 281
            set['sections.' + i + '.elements'] = section.elements;                                                     // 282
            return true;                                                                                               // 283
          }                                                                                                            // 284
        });                                                                                                            // 285
      });                                                                                                              // 286
      ModelSheets.update(id, {                                                                                         // 287
        $set: set                                                                                                      // 288
      });                                                                                                              // 287
    }                                                                                                                  // 290
                                                                                                                       //
    return modelsheetsRemoveElement;                                                                                   // 79
  }(),                                                                                                                 // 79
  'modelsheets.updateElementField': function () {                                                                      // 291
    function modelsheetsUpdateElementField(id, elementId, fieldName, fieldVal) {                                       // 79
      check(id, String);                                                                                               // 292
      check(elementId, String);                                                                                        // 293
      check(fieldName, String);                                                                                        // 294
                                                                                                                       //
      if (!this.userId) {                                                                                              // 296
        throw new Meteor.Error('not-authorized');                                                                      // 297
      }                                                                                                                // 298
      var model = ModelSheets.findOne(id);                                                                             // 299
      if (!model) {                                                                                                    // 300
        throw new Meteor.Error('not-found');                                                                           // 301
      }                                                                                                                // 302
      if (model.owner !== this.userId) {                                                                               // 303
        throw new Meteor.Error('not-authorized');                                                                      // 304
      }                                                                                                                // 305
      var set = {};                                                                                                    // 306
      // exception for the 3 numbers ( client does not care about it )                                                 // 307
      if (fieldName === 'size' || fieldName === 'table.rows' || fieldName === 'table.cols') {                          // 308
        fieldVal = parseInt(fieldVal);                                                                                 // 309
      }                                                                                                                // 310
      model.sections.some(function (s, i) {                                                                            // 311
        return s.elements.some(function (e, j) {                                                                       // 312
          if (e.id === elementId) {                                                                                    // 313
            set['sections.' + i + '.elements.' + j + '.' + fieldName] = fieldVal;                                      // 314
            return true;                                                                                               // 315
          }                                                                                                            // 316
        });                                                                                                            // 317
      });                                                                                                              // 318
      ModelSheets.update(id, {                                                                                         // 319
        $set: set                                                                                                      // 320
      });                                                                                                              // 319
    }                                                                                                                  // 322
                                                                                                                       //
    return modelsheetsUpdateElementField;                                                                              // 79
  }(),                                                                                                                 // 79
  'modelsheets.changeSectionsPosition': function () {                                                                  // 323
    function modelsheetsChangeSectionsPosition(id, order) {                                                            // 79
      check(id, String);                                                                                               // 324
      check(order, Array);                                                                                             // 325
                                                                                                                       //
      var model = ModelSheets.findOne(id);                                                                             // 327
      if (!model || !this.userId || this.userId !== model.owner) {                                                     // 328
        throw new Meteor.Error('not-authorized');                                                                      // 329
      }                                                                                                                // 330
                                                                                                                       //
      var sections = model.sections;                                                                                   // 332
      var newSections = [];                                                                                            // 333
                                                                                                                       //
      order.forEach(function (sectionId) {                                                                             // 335
        newSections.push(sections.find(function (s) {                                                                  // 336
          return s.id === sectionId;                                                                                   // 336
        }));                                                                                                           // 336
      });                                                                                                              // 337
                                                                                                                       //
      ModelSheets.update(id, {                                                                                         // 339
        $set: {                                                                                                        // 340
          sections: newSections                                                                                        // 341
        }                                                                                                              // 340
      });                                                                                                              // 339
    }                                                                                                                  // 344
                                                                                                                       //
    return modelsheetsChangeSectionsPosition;                                                                          // 79
  }(),                                                                                                                 // 79
  'modelsheets.cloneSection': function () {                                                                            // 345
    function modelsheetsCloneSection(id, sectionId) {                                                                  // 79
      check(id, String);                                                                                               // 346
      check(sectionId, String);                                                                                        // 347
                                                                                                                       //
      if (!this.userId) {                                                                                              // 349
        throw new Meteor.Error('not-authorized');                                                                      // 350
      }                                                                                                                // 351
      var model = ModelSheets.findOne(id);                                                                             // 352
      var section = model.sections.find(function (s) {                                                                 // 353
        return s.id === sectionId;                                                                                     // 353
      });                                                                                                              // 353
                                                                                                                       //
      // on change les ids des éléments et de la section                                                               // 355
      section.id = Random.id();                                                                                        // 356
      section.elements.forEach(function (e) {                                                                          // 357
        e.id = Random.id();                                                                                            // 358
      });                                                                                                              // 359
      ModelSheets.update(id, {                                                                                         // 360
        $push: {                                                                                                       // 361
          sections: section                                                                                            // 362
        }                                                                                                              // 361
      });                                                                                                              // 360
    }                                                                                                                  // 365
                                                                                                                       //
    return modelsheetsCloneSection;                                                                                    // 79
  }(),                                                                                                                 // 79
  'modelsheets.clone': function () {                                                                                   // 366
    function modelsheetsClone(id) {                                                                                    // 79
      check(id, String);                                                                                               // 367
      if (!this.userId) {                                                                                              // 368
        throw new Meteor.Error('not-authorized');                                                                      // 369
      }                                                                                                                // 370
      var model = ModelSheets.findOne(id);                                                                             // 371
      var sections = model.sections;                                                                                   // 372
      sections.forEach(function (section) {                                                                            // 373
        section.id = Random.id();                                                                                      // 374
        section.elements.forEach(function (e) {                                                                        // 375
          e.id = Random.id();                                                                                          // 376
        });                                                                                                            // 377
      });                                                                                                              // 378
      var newModel = {                                                                                                 // 379
        sections: sections,                                                                                            // 380
        owner: this.userId,                                                                                            // 381
        username: Meteor.users.findOne(this.userId).username,                                                          // 382
        name: 'COPY - ' + model.name,                                                                                  // 383
        'private': true,                                                                                               // 384
        language: model.language,                                                                                      // 385
        createdAt: new Date()                                                                                          // 386
      };                                                                                                               // 379
      ModelSheets.insert(newModel);                                                                                    // 388
    }                                                                                                                  // 389
                                                                                                                       //
    return modelsheetsClone;                                                                                           // 79
  }()                                                                                                                  // 79
});                                                                                                                    // 79
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"my-sheets.js":["babel-runtime/helpers/typeof","meteor/meteor","meteor/mongo","meteor/check","./rpgs","./model-sheets",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/my-sheets.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({Sheets:function(){return Sheets}});var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Rpgs;module.import('./rpgs',{"Rpgs":function(v){Rpgs=v}});var ModelSheets;module.import('./model-sheets',{"ModelSheets":function(v){ModelSheets=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       // 4
                                                                                                                       // 5
                                                                                                                       //
var Sheets = new Mongo.Collection('sheets');                                                                           // 7
                                                                                                                       //
// element.table                                                                                                       // 9
var TableElementSchema = new SimpleSchema({                                                                            // 10
	rows: { type: Number },                                                                                               // 11
	cols: { type: Number },                                                                                               // 12
	cases: { type: Object } // {} decrivant les cases ex Object.0.0 => 1er case ( contient label ) chaque case a 2 attr => value et label ( set par rm )
});                                                                                                                    // 10
                                                                                                                       //
// element                                                                                                             // 16
var ElementSchema = new SimpleSchema({                                                                                 // 17
	label: { type: String },                                                                                              // 18
	table: { type: TableElementSchema },                                                                                  // 19
	id: { type: String },                                                                                                 // 20
	type: { type: String }                                                                                                // 21
});                                                                                                                    // 17
                                                                                                                       //
var SectionSchema = new SimpleSchema({                                                                                 // 24
	id: { type: String },                                                                                                 // 25
	name: { type: String },                                                                                               // 26
	elements: { type: [ElementSchema] },                                                                                  // 27
	size: { type: Number }                                                                                                // 28
});                                                                                                                    // 24
                                                                                                                       //
var SheetHistory = new SimpleSchema({                                                                                  // 31
	raw: { type: String },                                                                                                // 32
	date: { type: Date },                                                                                                 // 33
	owner: { type: String },                                                                                              // 34
	username: { type: String },                                                                                           // 35
	id: { type: String }, // id generated at my demand allow to ident history entry                                       // 36
	previousVal: { type: String }                                                                                         // 37
});                                                                                                                    // 31
                                                                                                                       //
Sheets.schema = new SimpleSchema({                                                                                     // 40
	_id: { type: String, optional: true },                                                                                // 41
	model: { type: String },                                                                                              // 42
	sections: { type: [SectionSchema] },                                                                                  // 43
	owner: { type: String },                                                                                              // 44
	username: { type: String },                                                                                           // 45
	rpg: { type: String },                                                                                                // 46
	lock: { type: Boolean },                                                                                              // 47
	history: { type: [SheetHistory] }                                                                                     // 48
});                                                                                                                    // 40
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 51
	Meteor.publish('rpgSheet', function () {                                                                              // 52
		function sheetPublication(rpgId) {                                                                                   // 52
			// on ne peut récupérer que la feuille du rpg pour l'id du current user                                             // 53
			return Sheets.find({ owner: this.userId, rpg: rpgId });                                                             // 54
		}                                                                                                                    // 55
                                                                                                                       //
		return sheetPublication;                                                                                             // 52
	}());                                                                                                                 // 52
	Meteor.publish('rpgSheets', function () {                                                                             // 56
		function sheetPublication(rpgId) {                                                                                   // 56
			// on ne peut récupérer que la feuille du rpg pour l'id du current user                                             // 57
			return Sheets.find({ rpg: rpgId });                                                                                 // 58
		}                                                                                                                    // 59
                                                                                                                       //
		return sheetPublication;                                                                                             // 56
	}());                                                                                                                 // 56
}                                                                                                                      // 60
                                                                                                                       //
Meteor.methods({                                                                                                       // 62
	'sheets.updateElementField': function () {                                                                            // 63
		function sheetsUpdateElementField(id, elementId, fieldName, fieldVal) {                                              // 62
			var _this = this;                                                                                                   // 63
                                                                                                                       //
			if (Meteor.isClient) return;                                                                                        // 64
			check(id, String);                                                                                                  // 65
			check(elementId, String);                                                                                           // 66
			check(fieldName, String);                                                                                           // 67
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 69
				throw new Meteor.Error('not-authorized');                                                                          // 70
			}                                                                                                                   // 71
			var sheet = Sheets.findOne(id);                                                                                     // 72
                                                                                                                       //
			if (!sheet) {                                                                                                       // 74
				throw new Meteor.Error('not-found');                                                                               // 75
			}                                                                                                                   // 76
			var rpg = Rpgs.findOne(sheet.rpg);                                                                                  // 77
			if (sheet.lock === true && rpg.roleMaster !== this.userId) {                                                        // 78
				// lock by roleMaster                                                                                              // 79
				throw new Meteor.Error('not-authorized');                                                                          // 80
			}                                                                                                                   // 81
			if (sheet.owner !== this.userId && rpg.roleMaster !== this.userId) {                                                // 82
				throw new Meteor.Error('not-authorized');                                                                          // 83
			}                                                                                                                   // 84
			var set = {};                                                                                                       // 85
			var push = {};                                                                                                      // 86
			sheet.sections.some(function (s, i) {                                                                               // 87
				return s.elements.some(function (e, j) {                                                                           // 88
					if (e.id === elementId) {                                                                                         // 89
						var _ret = function () {                                                                                         // 89
							// calcul previous val                                                                                          // 90
							var previousVal = sheet.sections[i].elements[j];                                                                // 91
							var keys = fieldName.split('.');                                                                                // 92
							keys.some(function (k) {                                                                                        // 93
								if (!!previousVal[k]) {                                                                                        // 94
									previousVal = previousVal[k];                                                                                 // 95
								} else {                                                                                                       // 96
									previousVal = '';                                                                                             // 97
									return true; // to stop it                                                                                    // 98
								}                                                                                                              // 99
							});                                                                                                             // 100
                                                                                                                       //
							set['sections.' + i + '.elements.' + j + '.' + fieldName] = fieldVal;                                           // 102
							push['history'] = {                                                                                             // 103
								$each: [{                                                                                                      // 104
									raw: 'sections.' + i + '.elements.' + j + '.' + fieldName,                                                    // 106
									date: new Date(),                                                                                             // 107
									owner: _this.userId,                                                                                          // 108
									username: Meteor.users.findOne(_this.userId).username,                                                        // 109
									id: Random.id(),                                                                                              // 110
									previousVal: previousVal                                                                                      // 111
								}],                                                                                                            // 105
								$position: 0                                                                                                   // 114
							};                                                                                                              // 103
							return {                                                                                                        // 116
								v: true                                                                                                        // 116
							};                                                                                                              // 116
						}();                                                                                                             // 89
                                                                                                                       //
						if ((typeof _ret === 'undefined' ? 'undefined' : _typeof(_ret)) === "object") return _ret.v;                     // 89
					}                                                                                                                 // 117
				});                                                                                                                // 118
			});                                                                                                                 // 119
			Sheets.update(id, {                                                                                                 // 120
				$set: set,                                                                                                         // 121
				$push: push                                                                                                        // 122
			});                                                                                                                 // 120
		}                                                                                                                    // 124
                                                                                                                       //
		return sheetsUpdateElementField;                                                                                     // 62
	}(),                                                                                                                  // 62
	'sheets.setLock': function () {                                                                                       // 125
		function sheetsSetLock(rpgId, playerId) {                                                                            // 62
			check(playerId, String);                                                                                            // 126
			check(rpgId, String);                                                                                               // 127
                                                                                                                       //
			var sheet = Sheets.findOne({ owner: playerId, rpg: rpgId });                                                        // 129
			if (!sheet) {                                                                                                       // 130
				throw new Meteor.Error('not-found');                                                                               // 131
			}                                                                                                                   // 132
                                                                                                                       //
			var rpg = Rpgs.findOne(rpgId);                                                                                      // 134
			// only RM can lock or unlock                                                                                       // 135
			if (!this.userId || rpg.roleMaster !== this.userId) {                                                               // 136
				throw new Meteor.Error('not-authorized');                                                                          // 137
			}                                                                                                                   // 138
                                                                                                                       //
			Sheets.update(sheet._id, {                                                                                          // 140
				$set: {                                                                                                            // 141
					lock: !sheet.lock                                                                                                 // 142
				}                                                                                                                  // 141
			});                                                                                                                 // 140
		}                                                                                                                    // 145
                                                                                                                       //
		return sheetsSetLock;                                                                                                // 62
	}(),                                                                                                                  // 62
	'sheets.cancelHistory': function () {                                                                                 // 146
		function sheetsCancelHistory(sheetId, historyId) {                                                                   // 62
			check(sheetId, String);                                                                                             // 147
			check(historyId, String);                                                                                           // 148
                                                                                                                       //
			var sheet = Sheets.findOne(sheetId);                                                                                // 150
			if (!sheet) {                                                                                                       // 151
				throw new Meteor.Error('not-found');                                                                               // 152
			}                                                                                                                   // 153
			var rpg = Rpgs.findOne(sheet.rpg);                                                                                  // 154
			if (!this.userId || rpg.roleMaster !== this.userId) {                                                               // 155
				throw new Meteor.Error('not-authorized');                                                                          // 156
			}                                                                                                                   // 157
			var historyEntry = sheet.history.find(function (h) {                                                                // 158
				return h.id === historyId;                                                                                         // 158
			});                                                                                                                 // 158
			var set = {};                                                                                                       // 159
			set[historyEntry.raw] = historyEntry.previousVal || '';                                                             // 160
			Sheets.update(sheetId, {                                                                                            // 161
				$set: set,                                                                                                         // 162
				$pull: {                                                                                                           // 163
					history: { id: historyId }                                                                                        // 164
				}                                                                                                                  // 163
			});                                                                                                                 // 161
		}                                                                                                                    // 167
                                                                                                                       //
		return sheetsCancelHistory;                                                                                          // 62
	}()                                                                                                                   // 62
});                                                                                                                    // 62
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"notes.js":["meteor/meteor","meteor/mongo","meteor/check","./rpgs.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/notes.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({Notes:function(){return Notes}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Rpgs;module.import('./rpgs.js',{"Rpgs":function(v){Rpgs=v}});
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       // 4
                                                                                                                       //
var Notes = new Mongo.Collection('notes');                                                                             // 6
                                                                                                                       //
Notes.schema = new SimpleSchema({                                                                                      // 8
	_id: { type: String, optional: true },                                                                                // 9
	owner: { type: String },                                                                                              // 10
	username: { type: String },                                                                                           // 11
	attachedTo: { type: String, optional: true },                                                                         // 12
	rpg: { type: String },                                                                                                // 13
	content: { type: String }                                                                                             // 14
});                                                                                                                    // 8
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 18
	Meteor.publish('notes.rpg', function (rpgId) {                                                                        // 19
		return Notes.find({                                                                                                  // 20
			owner: this.userId,                                                                                                 // 21
			rpg: rpgId                                                                                                          // 22
		});                                                                                                                  // 20
	});                                                                                                                   // 24
}                                                                                                                      // 25
                                                                                                                       //
Meteor.methods({                                                                                                       // 27
	'notes.insert': function () {                                                                                         // 28
		function notesInsert(rpgId, content) {                                                                               // 27
			check(rpgId, String);                                                                                               // 29
			check(content, String);                                                                                             // 30
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 32
				throw new Meteor.Error('not-authorized');                                                                          // 33
			}                                                                                                                   // 34
			var note = {                                                                                                        // 35
				owner: this.userId,                                                                                                // 36
				username: Meteor.users.findOne(this.userId).username,                                                              // 37
				rpg: rpgId,                                                                                                        // 38
				content: content                                                                                                   // 39
			};                                                                                                                  // 35
			Notes.schema.validate(note);                                                                                        // 41
			Notes.insert(note);                                                                                                 // 42
		}                                                                                                                    // 43
                                                                                                                       //
		return notesInsert;                                                                                                  // 27
	}(),                                                                                                                  // 27
	'notes.update': function () {                                                                                         // 44
		function notesUpdate(id, content) {                                                                                  // 27
			check(id, String);                                                                                                  // 45
			check(content, String);                                                                                             // 46
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 48
				throw new Meteor.Error('not-authorized');                                                                          // 49
			}                                                                                                                   // 50
                                                                                                                       //
			Notes.update({ _id: id, owner: this.userId }, {                                                                     // 52
				$set: {                                                                                                            // 53
					content: content                                                                                                  // 54
				}                                                                                                                  // 53
			});                                                                                                                 // 52
		}                                                                                                                    // 57
                                                                                                                       //
		return notesUpdate;                                                                                                  // 27
	}(),                                                                                                                  // 27
	'notes.remove': function () {                                                                                         // 58
		function notesRemove(id) {                                                                                           // 27
			check(id, String);                                                                                                  // 59
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 61
				throw new Meteor.Error('not-authorized');                                                                          // 62
			}                                                                                                                   // 63
                                                                                                                       //
			Notes.remove({ _id: id, owner: this.userId });                                                                      // 65
		}                                                                                                                    // 66
                                                                                                                       //
		return notesRemove;                                                                                                  // 27
	}()                                                                                                                   // 27
});                                                                                                                    // 27
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"pnjs.js":["meteor/meteor","meteor/mongo","meteor/check","./rpgs.js","./model-sheets",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/pnjs.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({Pnjs:function(){return Pnjs}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Rpgs;module.import('./rpgs.js',{"Rpgs":function(v){Rpgs=v}});var ModelSheets;module.import('./model-sheets',{"ModelSheets":function(v){ModelSheets=v}});
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       // 4
                                                                                                                       // 5
                                                                                                                       //
var Pnjs = new Mongo.Collection('pnjs');                                                                               // 7
                                                                                                                       //
Pnjs.schema = new SimpleSchema({                                                                                       // 9
	_id: { type: String, optional: true },                                                                                // 10
	name: { type: String },                                                                                               // 11
	rpg: { type: String },                                                                                                // 12
	owner: { type: String },                                                                                              // 13
	username: { type: String },                                                                                           // 14
	sheet: { type: Object }                                                                                               // 15
});                                                                                                                    // 9
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 18
	Meteor.publish('pnjs.rpg', function () {                                                                              // 19
		function positionsPublication(rpgId) {                                                                               // 19
			return Pnjs.find({                                                                                                  // 20
				rpg: rpgId,                                                                                                        // 21
				owner: this.userId // seul le mj pourra en créer                                                                   // 22
			});                                                                                                                 // 20
		}                                                                                                                    // 24
                                                                                                                       //
		return positionsPublication;                                                                                         // 19
	}());                                                                                                                 // 19
}                                                                                                                      // 25
                                                                                                                       //
Meteor.methods({                                                                                                       // 27
	'pnjs.insert': function () {                                                                                          // 28
		function pnjsInsert(rpgId, name, modelSheetId) {                                                                     // 27
			check(rpgId, String);                                                                                               // 29
			check(name, String);                                                                                                // 30
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 32
				throw new Meteor.Error('not-authorized');                                                                          // 33
			}                                                                                                                   // 34
                                                                                                                       //
			var rpg = Rpgs.findOne(rpgId);                                                                                      // 36
			if (!rpg || rpg.roleMaster !== this.userId) {                                                                       // 37
				throw new Meteor.Error('not-authorized');                                                                          // 38
			}                                                                                                                   // 39
                                                                                                                       //
			var modelSheet = rpg.modelSheet;                                                                                    // 41
			if (modelSheetId && modelSheetId.length) {                                                                          // 42
				modelSheet = ModelSheets.findOne(modelSheetId);                                                                    // 43
			}                                                                                                                   // 44
                                                                                                                       //
			if (!modelSheet) {                                                                                                  // 46
				modelSheet = rpg.modelSheet;                                                                                       // 47
			}                                                                                                                   // 48
                                                                                                                       //
			Pnjs.insert({                                                                                                       // 50
				owner: this.userId,                                                                                                // 51
				username: Meteor.users.findOne(this.userId).username,                                                              // 52
				sheet: modelSheet, // contient sa feuille directement ( la collec sheet ne contient que des feuilles de joueurs )  // 53
				rpg: rpgId,                                                                                                        // 54
				name: name                                                                                                         // 55
			});                                                                                                                 // 50
		}                                                                                                                    // 57
                                                                                                                       //
		return pnjsInsert;                                                                                                   // 27
	}(),                                                                                                                  // 27
	'pnjs.sheet.updateElementField': function () {                                                                        // 58
		function pnjsSheetUpdateElementField(id, elementId, fieldName, fieldVal) {                                           // 27
			check(id, String);                                                                                                  // 59
			check(elementId, String);                                                                                           // 60
			check(fieldName, String);                                                                                           // 61
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 63
				throw new Meteor.Error('not-authorized');                                                                          // 64
			}                                                                                                                   // 65
                                                                                                                       //
			var pnj = Pnjs.findOne(id);                                                                                         // 67
			if (pnj.owner !== this.userId) {                                                                                    // 68
				throw new Meteor.Error('not-authorized');                                                                          // 69
			}                                                                                                                   // 70
                                                                                                                       //
			var sheet = pnj.sheet;                                                                                              // 72
			var set = {};                                                                                                       // 73
			sheet.sections.some(function (section, indexS) {                                                                    // 74
				return section.elements.some(function (element, indexE) {                                                          // 75
					if (element.id === elementId) {                                                                                   // 76
						set['sheet.sections.' + indexS + '.elements.' + indexE + '.' + fieldName] = fieldVal;                            // 77
						return true;                                                                                                     // 78
					}                                                                                                                 // 79
				});                                                                                                                // 80
			});                                                                                                                 // 81
			Pnjs.update(id, {                                                                                                   // 82
				$set: set                                                                                                          // 83
			});                                                                                                                 // 82
		}                                                                                                                    // 85
                                                                                                                       //
		return pnjsSheetUpdateElementField;                                                                                  // 27
	}(),                                                                                                                  // 27
	'pnjs.remove': function () {                                                                                          // 86
		function pnjsRemove(id) {                                                                                            // 27
			check(id, String);                                                                                                  // 87
			if (!this.userId) {                                                                                                 // 88
				throw new Meteor.Error('not-authorized');                                                                          // 89
			}                                                                                                                   // 90
                                                                                                                       //
			var pnj = Pnjs.findOne(id);                                                                                         // 92
			if (pnj.owner !== this.userId) {                                                                                    // 93
				throw new Meteor.Error('not-authorized');                                                                          // 94
			}                                                                                                                   // 95
                                                                                                                       //
			Pnjs.remove(id);                                                                                                    // 97
		}                                                                                                                    // 98
                                                                                                                       //
		return pnjsRemove;                                                                                                   // 27
	}()                                                                                                                   // 27
});                                                                                                                    // 27
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"positions.js":["meteor/meteor","meteor/mongo","meteor/check",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/positions.js                                                                                            //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({Positions:function(){return Positions}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
var Positions = new Mongo.Collection('positions');                                                                     // 5
                                                                                                                       //
Positions.schema = new SimpleSchema({                                                                                  // 7
	_id: { type: String, optional: true },                                                                                // 8
	owner: { type: String },                                                                                              // 9
	rpg: { type: String },                                                                                                // 10
	elementId: { type: String },                                                                                          // 11
	left: { type: Number },                                                                                               // 12
	top: { type: Number },                                                                                                // 13
	offsetTop: { type: Number, optional: true },                                                                          // 14
	offsetLeft: { type: Number, optional: true },                                                                         // 15
	vertical: { type: Boolean, optional: true }                                                                           // 16
});                                                                                                                    // 7
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 19
	Meteor.publish('positions.rpg', function () {                                                                         // 20
		function positionsPublication(rpgId) {                                                                               // 20
			return Positions.find({                                                                                             // 21
				rpg: rpgId,                                                                                                        // 22
				owner: this.userId                                                                                                 // 23
			});                                                                                                                 // 21
		}                                                                                                                    // 25
                                                                                                                       //
		return positionsPublication;                                                                                         // 20
	}());                                                                                                                 // 20
}                                                                                                                      // 26
                                                                                                                       //
Meteor.methods({                                                                                                       // 28
	'positions.insertOrUpdate': function () {                                                                             // 29
		function positionsInsertOrUpdate(rpgId, elemId, left, top) {                                                         // 28
			check(rpgId, String);                                                                                               // 30
			check(elemId, String);                                                                                              // 31
			check(left, Number);                                                                                                // 32
			check(top, Number);                                                                                                 // 33
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 35
				throw new Meteor.Error('not-authorized');                                                                          // 36
			}                                                                                                                   // 37
                                                                                                                       //
			var position = Positions.findOne({                                                                                  // 39
				owner: this.userId,                                                                                                // 40
				rpg: rpgId,                                                                                                        // 41
				elementId: elemId                                                                                                  // 42
			});                                                                                                                 // 39
			if (!position) {                                                                                                    // 44
				// create                                                                                                          // 45
				var newPosition = {                                                                                                // 46
					owner: this.userId,                                                                                               // 47
					rpg: rpgId,                                                                                                       // 48
					elementId: elemId,                                                                                                // 49
					left: left,                                                                                                       // 50
					top: top,                                                                                                         // 51
					vertical: false                                                                                                   // 52
				};                                                                                                                 // 46
				Positions.schema.validate(newPosition);                                                                            // 54
				Positions.insert(newPosition);                                                                                     // 55
			} else {                                                                                                            // 56
				// update                                                                                                          // 57
				Positions.update(position._id, {                                                                                   // 58
					$set: {                                                                                                           // 59
						left: left,                                                                                                      // 60
						top: top                                                                                                         // 61
					}                                                                                                                 // 59
				});                                                                                                                // 58
			}                                                                                                                   // 64
		}                                                                                                                    // 65
                                                                                                                       //
		return positionsInsertOrUpdate;                                                                                      // 28
	}(),                                                                                                                  // 28
	'positions.insertOrUpdateVertical': function () {                                                                     // 66
		function positionsInsertOrUpdateVertical(rpgId, elemId, vertical) {                                                  // 28
			check(rpgId, String);                                                                                               // 67
			check(elemId, String);                                                                                              // 68
			check(vertical, Boolean);                                                                                           // 69
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 71
				throw new Meteor.Error('not-authorized');                                                                          // 72
			}                                                                                                                   // 73
                                                                                                                       //
			var position = Positions.findOne({                                                                                  // 75
				owner: this.userId,                                                                                                // 76
				rpg: rpgId,                                                                                                        // 77
				elementId: elemId                                                                                                  // 78
			});                                                                                                                 // 75
			if (!position) {                                                                                                    // 80
				// create                                                                                                          // 81
				var newPosition = {                                                                                                // 82
					owner: this.userId,                                                                                               // 83
					rpg: rpgId,                                                                                                       // 84
					elementId: elemId,                                                                                                // 85
					left: 10,                                                                                                         // 86
					top: 10,                                                                                                          // 87
					vertical: vertical                                                                                                // 88
				};                                                                                                                 // 82
				Positions.schema.validate(newPosition);                                                                            // 90
				Positions.insert(newPosition);                                                                                     // 91
			} else {                                                                                                            // 92
				// update                                                                                                          // 93
				Positions.update(position._id, {                                                                                   // 94
					$set: {                                                                                                           // 95
						vertical: vertical                                                                                               // 96
					}                                                                                                                 // 95
				});                                                                                                                // 94
			}                                                                                                                   // 99
		}                                                                                                                    // 100
                                                                                                                       //
		return positionsInsertOrUpdateVertical;                                                                              // 28
	}(),                                                                                                                  // 28
	'positions.remove': function () {                                                                                     // 101
		function positionsRemove(rpgId) {                                                                                    // 28
			check(rpgId, String);                                                                                               // 102
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 104
				throw new Meteor.Error('not-authorized');                                                                          // 105
			}                                                                                                                   // 106
                                                                                                                       //
			Positions.update({                                                                                                  // 108
				owner: this.userId,                                                                                                // 110
				rpg: rpgId                                                                                                         // 111
			}, {                                                                                                                // 109
				$set: {                                                                                                            // 114
					left: 10,                                                                                                         // 115
					top: 10,                                                                                                          // 116
					vertical: false                                                                                                   // 117
				}                                                                                                                  // 114
			}, {                                                                                                                // 113
				multi: true                                                                                                        // 121
			});                                                                                                                 // 120
		}                                                                                                                    // 124
                                                                                                                       //
		return positionsRemove;                                                                                              // 28
	}()                                                                                                                   // 28
});                                                                                                                    // 28
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"posts.js":["meteor/meteor","meteor/mongo","meteor/check",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/posts.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({Posts:function(){return Posts}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
var Posts = new Mongo.Collection('posts');                                                                             // 5
                                                                                                                       //
var PostVote = new SimpleSchema({                                                                                      // 7
	owner: { type: String },                                                                                              // 8
	vote: { type: Boolean }                                                                                               // 9
});                                                                                                                    // 7
                                                                                                                       //
Posts.schema = new SimpleSchema({                                                                                      // 12
	_id: { type: String, optional: true },                                                                                // 13
	owner: { type: String },                                                                                              // 14
	username: { type: String },                                                                                           // 15
	title: { type: String },                                                                                              // 16
	content: { type: String },                                                                                            // 17
	votes: { type: [PostVote], optional: true },                                                                          // 18
	createdAt: { type: Date }                                                                                             // 19
});                                                                                                                    // 12
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 22
	Meteor.publish('posts', function () {                                                                                 // 23
		function positionsPublication(rpgId) {                                                                               // 23
			return Posts.find({});                                                                                              // 24
		}                                                                                                                    // 25
                                                                                                                       //
		return positionsPublication;                                                                                         // 23
	}());                                                                                                                 // 23
}                                                                                                                      // 26
                                                                                                                       //
Meteor.methods({                                                                                                       // 28
	'posts.insert': function () {                                                                                         // 29
		function postsInsert(title, content) {                                                                               // 28
			check(title, String);                                                                                               // 30
			check(content, String);                                                                                             // 31
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 33
				throw new Meteor.Error('not-authorized');                                                                          // 34
			}                                                                                                                   // 35
			var post = {                                                                                                        // 36
				owner: this.userId,                                                                                                // 37
				username: Meteor.users.findOne(this.userId).username,                                                              // 38
				title: title,                                                                                                      // 39
				content: content,                                                                                                  // 40
				createdAt: new Date()                                                                                              // 41
			};                                                                                                                  // 36
                                                                                                                       //
			Posts.schema.validate(post);                                                                                        // 44
			Posts.insert(post);                                                                                                 // 45
		}                                                                                                                    // 46
                                                                                                                       //
		return postsInsert;                                                                                                  // 28
	}()                                                                                                                   // 28
});                                                                                                                    // 28
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"rc-files.js":["meteor/meteor","meteor/mongo","meteor/check","./rpgs.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/rc-files.js                                                                                             //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({RcFiles:function(){return RcFiles}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Rpgs;module.import('./rpgs.js',{"Rpgs":function(v){Rpgs=v}});
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       // 4
                                                                                                                       //
var RcFiles = new FS.Collection("rcfiles", {                                                                           // 6
	stores: [new FS.Store.GridFS("rcfiles")],                                                                             // 7
	filter: {                                                                                                             // 8
		maxSize: 10485760, // in bytes                                                                                       // 9
		allow: {                                                                                                             // 10
			contentTypes: ['image/*', 'video/*', 'audio/*'],                                                                    // 11
			extensions: ['png', 'jpg', 'gif', 'mp3', 'mp4', 'jpeg']                                                             // 12
		},                                                                                                                   // 10
		onInvalid: function () {                                                                                             // 14
			function onInvalid(message) {                                                                                       // 14
				if (Meteor.isClient) {                                                                                             // 15
					bootbox.alert(message);                                                                                           // 16
				} else {                                                                                                           // 17
					console.log(message);                                                                                             // 18
				}                                                                                                                  // 19
			}                                                                                                                   // 20
                                                                                                                       //
			return onInvalid;                                                                                                   // 14
		}()                                                                                                                  // 14
	}                                                                                                                     // 8
});                                                                                                                    // 6
                                                                                                                       //
var UserShare = new SimpleSchema({                                                                                     // 24
	owner: { type: String },                                                                                              // 25
	username: { type: String }                                                                                            // 26
});                                                                                                                    // 24
var MetadataSchema = new SimpleSchema({                                                                                // 28
	owner: { type: String },                                                                                              // 29
	username: { type: String },                                                                                           // 30
	rpg: { type: String, optional: true },                                                                                // 31
	sharedTo: { type: [UserShare], optional: true },                                                                      // 32
	type: { type: String, optional: true },                                                                               // 33
	title: { type: String, optional: false }                                                                              // 34
});                                                                                                                    // 28
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 37
                                                                                                                       //
	RcFiles.allow({                                                                                                       // 39
		'insert': function () {                                                                                              // 40
			function insert(userId, doc) {                                                                                      // 40
				// add custom authentication code here                                                                             // 41
				if (!userId) {                                                                                                     // 42
					return false;                                                                                                     // 43
				}                                                                                                                  // 44
				if (!doc.metadata.rpg && doc.metadata.type !== 'avatar') {                                                         // 45
					return false;                                                                                                     // 46
				}                                                                                                                  // 47
				var files = RcFiles.find({                                                                                         // 48
					'metadata.owner': userId,                                                                                         // 49
					'metadata.rpg': doc.metadata.rpg                                                                                  // 50
				});                                                                                                                // 48
				// check size                                                                                                      // 52
				var size = 0;                                                                                                      // 53
				files.forEach(function (f) {                                                                                       // 54
					size += f.size();                                                                                                 // 55
				});                                                                                                                // 56
				if (size > 10485760) {                                                                                             // 57
					return false;                                                                                                     // 58
				}                                                                                                                  // 59
				return true;                                                                                                       // 60
			}                                                                                                                   // 61
                                                                                                                       //
			return insert;                                                                                                      // 40
		}(),                                                                                                                 // 40
		'update': function () {                                                                                              // 62
			function update(userId, doc) {                                                                                      // 62
				// add custom authentication code here                                                                             // 63
				return doc.metadata.owner === userId;                                                                              // 64
			}                                                                                                                   // 65
                                                                                                                       //
			return update;                                                                                                      // 62
		}(),                                                                                                                 // 62
		'download': function () {                                                                                            // 66
			function download(userId, doc) {                                                                                    // 66
				var _this = this;                                                                                                  // 66
                                                                                                                       //
				// add custom authentication code here                                                                             // 67
				if (doc.metadata.type === 'avatar') {                                                                              // 68
					return true;                                                                                                      // 69
				}                                                                                                                  // 70
				if (doc.metadata.sharedTo && doc.metadata.sharedTo.find(function (u) {                                             // 71
					return u.owner === _this.userId;                                                                                  // 71
				})) {                                                                                                              // 71
					return true;                                                                                                      // 72
				}                                                                                                                  // 73
				// si pas avatar, on refuse le download ( pour le moment )                                                         // 74
				return doc.metadata.owner === userId;                                                                              // 75
			}                                                                                                                   // 76
                                                                                                                       //
			return download;                                                                                                    // 66
		}(),                                                                                                                 // 66
		remove: function () {                                                                                                // 77
			function remove(userId, doc) {                                                                                      // 77
				return doc.metadata.owner === userId;                                                                              // 78
			}                                                                                                                   // 79
                                                                                                                       //
			return remove;                                                                                                      // 77
		}()                                                                                                                  // 77
	});                                                                                                                   // 39
                                                                                                                       //
	Meteor.publish('rcfiles.rpg', function () {                                                                           // 82
		function rcFilesPublication(rpgId) {                                                                                 // 82
			if (this.userId) {                                                                                                  // 83
				return RcFiles.find({                                                                                              // 84
                                                                                                                       //
					$or: [{                                                                                                           // 86
						'metadata.owner': this.userId,                                                                                   // 88
						'metadata.rpg': rpgId                                                                                            // 89
					}, {                                                                                                              // 87
						'metadata.sharedTo.owner': this.userId,                                                                          // 92
						'metadata.rpg': rpgId                                                                                            // 93
					}]                                                                                                                // 91
				});                                                                                                                // 84
			}                                                                                                                   // 97
		}                                                                                                                    // 98
                                                                                                                       //
		return rcFilesPublication;                                                                                           // 82
	}());                                                                                                                 // 82
                                                                                                                       //
	Meteor.publish('rcfiles.rpg.avatar', function () {                                                                    // 100
		function rcFilesRpgAvatars(rpgId) {                                                                                  // 100
			var rpg = Rpgs.findOne(rpgId);                                                                                      // 101
			var ids = rpg.players.map(function (p) {                                                                            // 102
				return p.owner;                                                                                                    // 102
			});                                                                                                                 // 102
			ids.push(rpg.roleMaster);                                                                                           // 103
			return RcFiles.find({                                                                                               // 104
				'metadata.owner': {                                                                                                // 105
					$in: ids                                                                                                          // 106
				},                                                                                                                 // 105
				'metadata.type': 'avatar'                                                                                          // 108
			});                                                                                                                 // 104
		}                                                                                                                    // 110
                                                                                                                       //
		return rcFilesRpgAvatars;                                                                                            // 100
	}());                                                                                                                 // 100
}                                                                                                                      // 112
                                                                                                                       //
Meteor.methods({                                                                                                       // 114
	'rcfiles.share': function () {                                                                                        // 115
		function rcfilesShare(id, ownerId) {                                                                                 // 114
			check(id, String);                                                                                                  // 116
			check(ownerId, String);                                                                                             // 117
                                                                                                                       //
			var file = RcFiles.findOne(id);                                                                                     // 119
                                                                                                                       //
			var sharedTo = file.metadata.sharedTo;                                                                              // 121
			if (!sharedTo) {                                                                                                    // 122
				sharedTo = [];                                                                                                     // 123
			}                                                                                                                   // 124
			var found = false;                                                                                                  // 125
			sharedTo.some(function (u, i) {                                                                                     // 126
				if (u.owner === ownerId) {                                                                                         // 127
					sharedTo.splice(i, 1);                                                                                            // 128
					found = true;                                                                                                     // 129
					return true;                                                                                                      // 130
				}                                                                                                                  // 131
			});                                                                                                                 // 132
			if (!found) {                                                                                                       // 133
				// add it                                                                                                          // 134
				sharedTo.push({                                                                                                    // 135
					owner: ownerId,                                                                                                   // 136
					username: Meteor.users.findOne(ownerId)                                                                           // 137
				});                                                                                                                // 135
			}                                                                                                                   // 139
			RcFiles.update(id, {                                                                                                // 140
				$set: {                                                                                                            // 141
					'metadata.sharedTo': sharedTo                                                                                     // 142
				}                                                                                                                  // 141
			});                                                                                                                 // 140
		}                                                                                                                    // 145
                                                                                                                       //
		return rcfilesShare;                                                                                                 // 114
	}()                                                                                                                   // 114
});                                                                                                                    // 114
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"rolls.js":["babel-runtime/helpers/typeof","meteor/meteor","meteor/mongo","meteor/check","./rpgs.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/rolls.js                                                                                                //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({Rolls:function(){return Rolls}});var _typeof;module.import('babel-runtime/helpers/typeof',{"default":function(v){_typeof=v}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var Rpgs;module.import('./rpgs.js',{"Rpgs":function(v){Rpgs=v}});
                                                                                                                       // 1
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       // 4
                                                                                                                       //
var Rolls = new Mongo.Collection('rolls');                                                                             // 6
                                                                                                                       //
var Result = new SimpleSchema({                                                                                        // 8
	type: { type: Number },                                                                                               // 9
	result: { type: Number }                                                                                              // 10
});                                                                                                                    // 8
                                                                                                                       //
Rolls.schema = new SimpleSchema({                                                                                      // 13
	_id: { type: String, optional: true },                                                                                // 14
	owner: { type: String }, // _id of user                                                                               // 15
	username: { type: String }, // username of user,                                                                      // 16
	rpg: { type: String },                                                                                                // 17
	date: { type: Date },                                                                                                 // 18
	results: { type: [Result] },                                                                                          // 19
	total: { type: Number },                                                                                              // 20
	date: { type: Date }                                                                                                  // 21
});                                                                                                                    // 13
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 24
	Meteor.publish('rolls.rpg', function () {                                                                             // 25
		function rollsRpgPublication(rpgId) {                                                                                // 25
			var rpg = Rpgs.findOne(rpgId);                                                                                      // 26
			if (this.userId === rpg.roleMaster) {                                                                               // 27
				return Rolls.find({                                                                                                // 28
					rpg: rpgId                                                                                                        // 30
				}, {                                                                                                               // 29
					sort: {                                                                                                           // 33
						date: -1                                                                                                         // 34
					},                                                                                                                // 33
					limit: 50                                                                                                         // 36
				});                                                                                                                // 32
			}                                                                                                                   // 39
		}                                                                                                                    // 40
                                                                                                                       //
		return rollsRpgPublication;                                                                                          // 25
	}());                                                                                                                 // 25
}                                                                                                                      // 41
                                                                                                                       //
Meteor.methods({                                                                                                       // 43
	'rolls.rollDices': function () {                                                                                      // 44
		function rollsRollDices(rpgId, val) {                                                                                // 43
			var _this = this;                                                                                                   // 44
                                                                                                                       //
			check(val, String);                                                                                                 // 45
			if (val.length < 3) {                                                                                               // 46
				throw new Meteor.Error('not-authorized');                                                                          // 47
			}                                                                                                                   // 48
			if (val.length > 50) {                                                                                              // 49
				throw new Meteor.Error('not-authorized');                                                                          // 50
			}                                                                                                                   // 51
			var roll = {};                                                                                                      // 52
			if (Meteor.isServer) {                                                                                              // 53
				var _ret = function () {                                                                                           // 53
					var rpg = Rpgs.findOne(rpgId);                                                                                    // 54
					var results = [];                                                                                                 // 55
					if (!_this.userId || !rpg) {                                                                                      // 56
						throw new Meteor.Error('not-authorized');                                                                        // 57
					}                                                                                                                 // 58
					if (rpg.roleMaster !== _this.userId) {                                                                            // 59
						if (!rpg.players.find(function (p) {                                                                             // 60
							return p.owner === _this.userId;                                                                                // 60
						})) {                                                                                                            // 60
							throw new Meteor.Error('not-authorized');                                                                       // 61
						}                                                                                                                // 62
					}                                                                                                                 // 63
					var total = 0;                                                                                                    // 64
					var aux = 0;                                                                                                      // 65
					var sep1 = ',';                                                                                                   // 66
					var sep2 = 'd';                                                                                                   // 67
					val.split(sep1).forEach(function (entry) {                                                                        // 68
						var diceNb = parseInt(entry.split(sep2)[0]);                                                                     // 69
						var diceType = parseInt(entry.split(sep2)[1]);                                                                   // 70
						if (diceNb > 20) {                                                                                               // 71
							throw new Meteor.Error('not-authorized');                                                                       // 72
						}                                                                                                                // 73
                                                                                                                       //
						for (var i = 0; i < diceNb; i++) {                                                                               // 75
							aux = parseInt(Math.random() * diceType) + 1;                                                                   // 76
							total += aux;                                                                                                   // 77
							results.push({                                                                                                  // 78
								type: diceType,                                                                                                // 79
								result: aux                                                                                                    // 80
							});                                                                                                             // 78
						}                                                                                                                // 82
					});                                                                                                               // 83
					roll = {                                                                                                          // 84
						owner: _this.userId,                                                                                             // 85
						username: Meteor.users.findOne(_this.userId).username,                                                           // 86
						rpg: rpgId,                                                                                                      // 87
						date: new Date(),                                                                                                // 88
						results: results,                                                                                                // 89
						total: total                                                                                                     // 90
					};                                                                                                                // 84
					Rolls.schema.validate(roll);                                                                                      // 92
					Rolls.insert(roll);                                                                                               // 93
					return {                                                                                                          // 94
						v: roll                                                                                                          // 94
					};                                                                                                                // 94
				}();                                                                                                               // 53
                                                                                                                       //
				if ((typeof _ret === 'undefined' ? 'undefined' : _typeof(_ret)) === "object") return _ret.v;                       // 53
			}                                                                                                                   // 95
		}                                                                                                                    // 97
                                                                                                                       //
		return rollsRollDices;                                                                                               // 43
	}()                                                                                                                   // 43
});                                                                                                                    // 43
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"rpgs.js":["meteor/meteor","meteor/mongo","meteor/check","./model-sheets.js","./my-sheets.js","./chats.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/rpgs.js                                                                                                 //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({Rpgs:function(){return Rpgs}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});var ModelSheets;module.import('./model-sheets.js',{"ModelSheets":function(v){ModelSheets=v}});var Sheets;module.import('./my-sheets.js',{"Sheets":function(v){Sheets=v}});var Chats;module.import('./chats.js',{"Chats":function(v){Chats=v}});
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       // 4
                                                                                                                       // 5
                                                                                                                       // 6
                                                                                                                       //
var Rpgs = new Mongo.Collection('rpgs');                                                                               // 8
                                                                                                                       //
var PlayerSchema = new SimpleSchema({                                                                                  // 10
	owner: { type: String }, // _id of user                                                                               // 11
	username: { type: String }, // username of user,                                                                      // 12
	interfaceLock: { type: Boolean, optional: true }                                                                      // 13
});                                                                                                                    // 10
                                                                                                                       //
Rpgs.schema = new SimpleSchema({                                                                                       // 16
	_id: { type: String, optional: true },                                                                                // 17
	name: { type: String, min: 1 },                                                                                       // 18
	modelSheet: { type: ModelSheets.schema },                                                                             // 19
	language: { type: String, min: 2 },                                                                                   // 20
	password: { type: String, optional: true },                                                                           // 21
	roleMaster: { type: String },                                                                                         // 22
	roleMasterUsername: { type: String },                                                                                 // 23
	roleMasterInterfaceLock: { type: Boolean, optional: true },                                                           // 24
	open: { type: Boolean },                                                                                              // 25
	players: { type: [PlayerSchema], optional: true },                                                                    // 26
	archived: { type: Boolean },                                                                                          // 27
	createdAt: { type: Date }                                                                                             // 28
});                                                                                                                    // 16
                                                                                                                       //
function getRpgQuery(onlyMine) {                                                                                       // 31
	var archived = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;                             // 31
                                                                                                                       //
	if (onlyMine) {                                                                                                       // 32
		return {                                                                                                             // 33
			archived: archived,                                                                                                 // 34
			$or: [{ roleMaster: this.userId }, { 'players.owner': this.userId }]                                                // 35
		};                                                                                                                   // 33
	} else {                                                                                                              // 40
		return {                                                                                                             // 41
			archived: archived,                                                                                                 // 42
			$or: [{ roleMaster: this.userId }, { 'players.owner': this.userId }, { 'open': true }]                              // 43
		};                                                                                                                   // 41
	}                                                                                                                     // 49
}                                                                                                                      // 50
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 52
	//list                                                                                                                // 53
	Meteor.publish('rpgs', function () {                                                                                  // 54
		function rpgsPublication(onlyMine) {                                                                                 // 54
			var archived = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;                           // 54
                                                                                                                       //
			return Rpgs.find(getRpgQuery.call(this, onlyMine, archived));                                                       // 55
		}                                                                                                                    // 56
                                                                                                                       //
		return rpgsPublication;                                                                                              // 54
	}());                                                                                                                 // 54
                                                                                                                       //
	// roleMasters list status                                                                                            // 58
	Meteor.publish('rpgsRoleMastersStatus', function () {                                                                 // 59
		function rpgsRoleMastersStatusPublication(onlyMine) {                                                                // 59
			var archived = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;                           // 59
                                                                                                                       //
			var userIds = [];                                                                                                   // 60
			Rpgs.find(getRpgQuery.call(this, onlyMine, archived)).forEach(function (rpg) {                                      // 61
				userIds.push(rpg.roleMaster);                                                                                      // 63
			});                                                                                                                 // 64
			return Meteor.users.find({                                                                                          // 65
				$and: [{ _id: { $in: userIds } }, { 'status.online': true }]                                                       // 67
			}, {                                                                                                                // 66
				fields: { status: 1 }                                                                                              // 73
			});                                                                                                                 // 72
		}                                                                                                                    // 76
                                                                                                                       //
		return rpgsRoleMastersStatusPublication;                                                                             // 59
	}());                                                                                                                 // 59
                                                                                                                       //
	// one rpg                                                                                                            // 78
	Meteor.publish('rpg', function () {                                                                                   // 79
		function rpgPublication(id) {                                                                                        // 79
			// Find rpg with _id == id & where user is already player or RM                                                     // 80
			return Rpgs.find({                                                                                                  // 81
				$and: [{ _id: id }, { $or: [{ roleMaster: this.userId }, { 'players.owner': this.userId }] }]                      // 82
			});                                                                                                                 // 81
		}                                                                                                                    // 90
                                                                                                                       //
		return rpgPublication;                                                                                               // 79
	}());                                                                                                                 // 79
	//publis all users of a rpg                                                                                           // 91
	Meteor.publish('rpgUsers', function () {                                                                              // 92
		function rpgUsersPublication(id) {                                                                                   // 92
			var rpg = Rpgs.findOne(id);                                                                                         // 93
			var ids = rpg.players.map(function (p) {                                                                            // 94
				return p.owner;                                                                                                    // 94
			});                                                                                                                 // 94
			ids.push(rpg.roleMaster);                                                                                           // 95
			return Meteor.users.find({ _id: { $in: ids } }, { fields: { status: 1 } });                                         // 96
		}                                                                                                                    // 100
                                                                                                                       //
		return rpgUsersPublication;                                                                                          // 92
	}());                                                                                                                 // 92
}                                                                                                                      // 101
                                                                                                                       //
Meteor.methods({                                                                                                       // 103
	'rpgs.insert': function () {                                                                                          // 104
		function rpgsInsert(name, language, modelSheet, password) {                                                          // 103
			check(name, String);                                                                                                // 105
			check(language, String);                                                                                            // 106
			check(modelSheet, String);                                                                                          // 107
			check(password, String);                                                                                            // 108
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 110
				throw new Meteor.Error('not-authorized');                                                                          // 111
			}                                                                                                                   // 112
                                                                                                                       //
			var model = ModelSheets.findOne(modelSheet);                                                                        // 114
			var rpg = {                                                                                                         // 115
				name: name,                                                                                                        // 116
				language: language,                                                                                                // 117
				modelSheet: model, // is a clone of model ( then the real one can be modify without changing the user experience )
				password: password,                                                                                                // 119
				roleMaster: this.userId,                                                                                           // 120
				roleMasterUsername: Meteor.users.findOne(this.userId).username,                                                    // 121
				open: true,                                                                                                        // 122
				players: [],                                                                                                       // 123
				archived: false,                                                                                                   // 124
				createdAt: new Date()                                                                                              // 125
			};                                                                                                                  // 115
			//Rpgs.schema.validate(rpg);                                                                                        // 127
			Rpgs.insert(rpg);                                                                                                   // 128
		}                                                                                                                    // 129
                                                                                                                       //
		return rpgsInsert;                                                                                                   // 103
	}(),                                                                                                                  // 103
	'rpgs.enterGame': function () {                                                                                       // 130
		function rpgsEnterGame(id) {                                                                                         // 103
			var _this = this;                                                                                                   // 130
                                                                                                                       //
			var password = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';                              // 130
                                                                                                                       //
			check(id, String);                                                                                                  // 131
			check(password, String);                                                                                            // 132
                                                                                                                       //
			if (!this.userId) {                                                                                                 // 134
				throw new Meteor.Error('not-authorized');                                                                          // 135
			}                                                                                                                   // 136
			// check if user not in rpg already & rpg is open to new players                                                    // 137
			var rpg = Rpgs.findOne(id);                                                                                         // 138
			if (!rpg) {                                                                                                         // 139
				throw new Meteor.Error(404, 'not-found');                                                                          // 140
			}                                                                                                                   // 141
			if (rpg.roleMaster === this.userId) {                                                                               // 142
				throw new Meteor.Error('not-authorized');                                                                          // 143
			}                                                                                                                   // 144
			if (rpg.players.some(function (p) {                                                                                 // 145
				return p.owner === _this.userId;                                                                                   // 145
			})) {                                                                                                               // 145
				throw new Meteor.Error('not-authorized');                                                                          // 146
			}                                                                                                                   // 147
			if (rpg.password && rpg.password.length) {                                                                          // 148
				if (rpg.password !== password) {                                                                                   // 149
					throw new Meteor.Error('not-authorized');                                                                         // 150
				}                                                                                                                  // 151
			}                                                                                                                   // 152
			if (rpg.archived) {                                                                                                 // 153
				throw new Meteor.Error('not-authorized');                                                                          // 154
			}                                                                                                                   // 155
                                                                                                                       //
			/* Generate sheet */                                                                                                // 157
			var model = rpg.modelSheet;                                                                                         // 158
			var username = Meteor.users.findOne(this.userId).username;                                                          // 159
                                                                                                                       //
			var sheet = {                                                                                                       // 161
				model: rpg.modelSheet._id,                                                                                         // 162
				sections: model.sections,                                                                                          // 163
				owner: this.userId,                                                                                                // 164
				username: username,                                                                                                // 165
				rpg: rpg._id,                                                                                                      // 166
				lock: false                                                                                                        // 167
			};                                                                                                                  // 161
			//Sheets.schema.validate(sheet);                                                                                    // 169
			sheet = Sheets.insert(sheet);                                                                                       // 170
                                                                                                                       //
			var newPlayer = {                                                                                                   // 172
				owner: this.userId,                                                                                                // 173
				username: username,                                                                                                // 174
				interfaceLock: false                                                                                               // 175
			};                                                                                                                  // 172
			// check schema                                                                                                     // 177
			PlayerSchema.validate(newPlayer);                                                                                   // 178
                                                                                                                       //
			Rpgs.update(id, {                                                                                                   // 180
				$push: {                                                                                                           // 181
					players: newPlayer                                                                                                // 182
				}                                                                                                                  // 181
			});                                                                                                                 // 180
                                                                                                                       //
			/* Create of add player to mainChat & create private one between */                                                 // 186
			var mainChat = Chats.findOne({                                                                                      // 187
				rpg: id,                                                                                                           // 188
				type: 'all-players'                                                                                                // 189
			});                                                                                                                 // 187
                                                                                                                       //
			if (!mainChat) {                                                                                                    // 192
				var newChat = {                                                                                                    // 193
					rpg: id,                                                                                                          // 194
					type: 'all-players',                                                                                              // 195
					name: 'all',                                                                                                      // 196
					users: [{                                                                                                         // 197
						owner: this.userId,                                                                                              // 199
						username: username,                                                                                              // 200
						unread: 0                                                                                                        // 201
					}, {                                                                                                              // 198
						owner: rpg.roleMaster,                                                                                           // 204
						username: rpg.roleMasterUsername,                                                                                // 205
						unread: 0                                                                                                        // 206
					}],                                                                                                               // 203
					messages: []                                                                                                      // 209
				};                                                                                                                 // 193
				Chats.schema.validate(newChat);                                                                                    // 211
				Chats.insert(newChat);                                                                                             // 212
			} else {                                                                                                            // 213
				Chats.update(mainChat._id, {                                                                                       // 214
					$push: {                                                                                                          // 215
						users: {                                                                                                         // 216
							owner: this.userId,                                                                                             // 217
							username: username,                                                                                             // 218
							unread: 0                                                                                                       // 219
						}                                                                                                                // 216
					}                                                                                                                 // 215
				});                                                                                                                // 214
			}                                                                                                                   // 223
                                                                                                                       //
			var newPrivateChat = {                                                                                              // 225
				rpg: id,                                                                                                           // 226
				name: username + ' - ' + rpg.roleMasterUsername,                                                                   // 227
				type: 'rm-player',                                                                                                 // 228
				users: [{                                                                                                          // 229
					owner: this.userId,                                                                                               // 231
					username: username,                                                                                               // 232
					unread: 0                                                                                                         // 233
				}, {                                                                                                               // 230
					owner: rpg.roleMaster,                                                                                            // 236
					username: rpg.roleMasterUsername,                                                                                 // 237
					unread: 0                                                                                                         // 238
				}],                                                                                                                // 235
				messages: []                                                                                                       // 241
			};                                                                                                                  // 225
			Chats.schema.validate(newPrivateChat);                                                                              // 243
			Chats.insert(newPrivateChat);                                                                                       // 244
		}                                                                                                                    // 245
                                                                                                                       //
		return rpgsEnterGame;                                                                                                // 103
	}(),                                                                                                                  // 103
	'rpgs.rm.setOpen': function () {                                                                                      // 246
		function rpgsRmSetOpen(id) {                                                                                         // 103
			check(id, String);                                                                                                  // 247
			if (!this.userId) {                                                                                                 // 248
				throw new Meteor.Error('not-authorized');                                                                          // 249
			}                                                                                                                   // 250
			// check if user not in rpg already & rpg is open to new players                                                    // 251
			var rpg = Rpgs.findOne(id);                                                                                         // 252
			if (!rpg) {                                                                                                         // 253
				throw new Meteor.Error(404, 'not-found');                                                                          // 254
			}                                                                                                                   // 255
			if (rpg.roleMaster !== this.userId) {                                                                               // 256
				throw new Meteor.Error('not-authorized');                                                                          // 257
			}                                                                                                                   // 258
			Rpgs.update(id, {                                                                                                   // 259
				$set: {                                                                                                            // 260
					open: !rpg.open                                                                                                   // 261
				}                                                                                                                  // 260
			});                                                                                                                 // 259
		}                                                                                                                    // 264
                                                                                                                       //
		return rpgsRmSetOpen;                                                                                                // 103
	}(),                                                                                                                  // 103
	'rpgs.setInterfaceLock': function () {                                                                                // 265
		function rpgsSetInterfaceLock(id) {                                                                                  // 103
			var _this2 = this;                                                                                                  // 265
                                                                                                                       //
			check(id, String);                                                                                                  // 266
			if (!this.userId) {                                                                                                 // 267
				throw new Meteor.Error('not-authorized');                                                                          // 268
			}                                                                                                                   // 269
			var rpg = Rpgs.findOne(id);                                                                                         // 270
			var set = {};                                                                                                       // 271
			if (rpg.roleMaster === this.userId) {                                                                               // 272
				var val = rpg.roleMasterInterfaceLock ? true : false;                                                              // 273
				set['roleMasterInterfaceLock'] = !val;                                                                             // 274
			} else {                                                                                                            // 275
				rpg.players.some(function (p, i) {                                                                                 // 276
					if (p.owner === _this2.userId) {                                                                                  // 277
						var _val = p.interfaceLock ? true : false;                                                                       // 278
						set['players.' + i + '.interfaceLock'] = !_val;                                                                  // 279
					}                                                                                                                 // 280
				});                                                                                                                // 281
			}                                                                                                                   // 282
                                                                                                                       //
			Rpgs.update(id, {                                                                                                   // 284
				$set: set                                                                                                          // 285
			});                                                                                                                 // 284
		}                                                                                                                    // 287
                                                                                                                       //
		return rpgsSetInterfaceLock;                                                                                         // 103
	}(),                                                                                                                  // 103
	'rpgs.setArchived': function () {                                                                                     // 288
		function rpgsSetArchived(id) {                                                                                       // 103
			check(id, String);                                                                                                  // 289
                                                                                                                       //
			var rpg = Rpgs.findOne({ _id: id, roleMaster: this.userId });                                                       // 291
			Rpgs.update({ _id: id, roleMaster: this.userId }, {                                                                 // 292
				$set: {                                                                                                            // 293
					archived: !rpg.archive                                                                                            // 294
				}                                                                                                                  // 293
			});                                                                                                                 // 292
		}                                                                                                                    // 297
                                                                                                                       //
		return rpgsSetArchived;                                                                                              // 103
	}()                                                                                                                   // 103
});                                                                                                                    // 103
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"translations.js":["meteor/meteor","meteor/mongo","meteor/check",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/api/translations.js                                                                                         //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({Translations:function(){return Translations}});var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});var check;module.import('meteor/check',{"check":function(v){check=v}});
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       //
var Translations = new Mongo.Collection('translations');                                                               // 5
                                                                                                                       //
// publications                                                                                                        // 7
if (Meteor.isServer) {                                                                                                 // 8
  // This code only runs on the server                                                                                 // 9
  Meteor.publish('translations', function () {                                                                         // 10
    function translationsPublication() {                                                                               // 10
      return Translations.find({});                                                                                    // 11
    }                                                                                                                  // 12
                                                                                                                       //
    return translationsPublication;                                                                                    // 10
  }());                                                                                                                // 10
}                                                                                                                      // 13
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"startup":{"init-db.js":["../api/translations.js","../api/db-init/translations.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// imports/startup/init-db.js                                                                                          //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
module.export({initDb:function(){return initDb}});var Translations;module.import('../api/translations.js',{"Translations":function(v){Translations=v}});
var fs = Npm.require("fs");                                                                                            // 2
                                                                                                                       //
function initDb() {                                                                                                    // 4
  initTranslations();                                                                                                  // 5
}                                                                                                                      // 6
                                                                                                                       //
function initTranslations() {var translations;module.import('../api/db-init/translations.js',{"translations":function(v){translations=v}});
                                                                                                                       // 9
  translations.forEach(function (entry) {                                                                              // 10
    var res = Translations.findOne({ key: entry.key });                                                                // 11
    if (res) {                                                                                                         // 12
      Translations.update(res._id, {                                                                                   // 13
        $set: {                                                                                                        // 14
          fr: entry.fr,                                                                                                // 15
          en: entry.en                                                                                                 // 16
        }                                                                                                              // 14
      });                                                                                                              // 13
    } else {                                                                                                           // 19
      Translations.insert(entry);                                                                                      // 20
    }                                                                                                                  // 21
  });                                                                                                                  // 22
}                                                                                                                      // 23
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["meteor/meteor","../imports/startup/init-db.js","meteor/xcv58:collection-api","../imports/api/model-sheets.js","../imports/api/translations.js","../imports/api/rpgs.js","../imports/api/rc-files.js","../imports/api/my-sheets.js","../imports/api/chats.js","../imports/api/drawings.js","../imports/api/rolls.js","../imports/api/positions.js","../imports/api/pnjs.js","../imports/api/posts.js","../imports/api/notes.js",function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                     //
// server/main.js                                                                                                      //
//                                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                       //
var Meteor;module.import('meteor/meteor',{"Meteor":function(v){Meteor=v}});var initDb;module.import('../imports/startup/init-db.js',{"initDb":function(v){initDb=v}});var CollectionAPI;module.import('meteor/xcv58:collection-api',{"CollectionAPI":function(v){CollectionAPI=v}});var ModelSheets;module.import('../imports/api/model-sheets.js',{"ModelSheets":function(v){ModelSheets=v}});module.import('../imports/api/model-sheets.js');module.import('../imports/api/translations.js');module.import('../imports/api/rpgs.js');module.import('../imports/api/rc-files.js');module.import('../imports/api/my-sheets.js');module.import('../imports/api/chats.js');module.import('../imports/api/drawings.js');module.import('../imports/api/rolls.js');module.import('../imports/api/positions.js');module.import('../imports/api/pnjs.js');module.import('../imports/api/posts.js');module.import('../imports/api/notes.js');
                                                                                                                       // 2
                                                                                                                       // 3
                                                                                                                       // 4
                                                                                                                       //
// import api                                                                                                          // 6
                                                                                                                       // 7
                                                                                                                       // 8
                                                                                                                       // 9
                                                                                                                       // 10
                                                                                                                       // 11
                                                                                                                       // 12
                                                                                                                       // 13
                                                                                                                       // 14
                                                                                                                       // 15
                                                                                                                       // 16
                                                                                                                       // 17
                                                                                                                       // 18
                                                                                                                       //
Meteor.startup(function () {                                                                                           // 21
  // code to run on server at startup                                                                                  // 22
  initDb();                                                                                                            // 23
                                                                                                                       //
  // let meteor uses 'custom_users' collection as 'users' collection                                                   // 25
  Accounts.users = new Mongo.Collection("rc_users", {                                                                  // 26
    _preventAutopublish: true                                                                                          // 27
  });                                                                                                                  // 26
                                                                                                                       //
  Meteor.users = Accounts.users;                                                                                       // 30
});                                                                                                                    // 31
                                                                                                                       //
if (Meteor.isServer) {                                                                                                 // 33
  Meteor.startup(function () {                                                                                         // 34
                                                                                                                       //
    // All values listed below are default                                                                             // 36
    collectionApi = new CollectionAPI({                                                                                // 37
      authToken: undefined, // Require this string to be passed in on each request                                     // 38
      apiPath: 'collectionapi', // API path prefix                                                                     // 39
      standAlone: false, // Run as a stand-alone HTTP(S) server                                                        // 40
      allowCORS: false, // Allow CORS (Cross-Origin Resource Sharing)                                                  // 41
      sslEnabled: false, // Disable/Enable SSL (stand-alone only)                                                      // 42
      listenPort: 3005, // Port to listen to (stand-alone only)                                                        // 43
      listenHost: undefined, // Host to bind to (stand-alone only)                                                     // 44
      privateKeyFile: undefined, // SSL private key file (only used if SSL is enabled)                                 // 45
      certificateFile: undefined, // SSL certificate key file (only used if SSL is enabled)                            // 46
      timeOut: 120000                                                                                                  // 47
    });                                                                                                                // 37
                                                                                                                       //
    // Add the collection Users to the API "/players" path                                                             // 50
    collectionApi.addCollection(Meteor.users, 'users', {                                                               // 51
      // All values listed below are default                                                                           // 52
      authToken: undefined, // Require this string to be passed in on each request.                                    // 53
      authenticate: undefined, // function(token, method, requestMetadata) {return true/false}; More details can found in [Authenticate Function](#Authenticate-Function).
      methods: ['POST', 'GET', 'PUT', 'DELETE'], // Allow creating, reading, updating, and deleting                    // 55
      before: { // This methods, if defined, will be called before the POST/GET/PUT/DELETE actions are performed on the collection.
        // If the function returns false the action will be canceled, if you return true the action will take place.   // 57
        POST: function () {                                                                                            // 58
          function POST(obj, requestMetadata, returnObject) {                                                          // 58
            // insert obj to your collection!                                                                          // 59
            returnObject.success = true;                                                                               // 60
            returnObject.statusCode = 201;                                                                             // 61
            returnObject.body = {                                                                                      // 62
              method: 'POST',                                                                                          // 63
              obj: obj                                                                                                 // 64
            };                                                                                                         // 62
                                                                                                                       //
            Accounts.createUser({                                                                                      // 67
              username: obj.username,                                                                                  // 68
              password: obj.plainPassword                                                                              // 69
            });                                                                                                        // 67
            return true;                                                                                               // 71
          }                                                                                                            // 72
                                                                                                                       //
          return POST;                                                                                                 // 58
        }(), // function(obj, requestMetadata, returnObject) {return true/false;},                                     // 58
        GET: undefined, // function(objs, requestMetadata, returnObject) {return true/false;},                         // 73
        PUT: undefined, // function(obj, newValues, requestMetadata, returnObject) {return true/false;},               // 74
        DELETE: undefined // function(obj, requestMetadata, returnObject) {return true/false;}                         // 75
      },                                                                                                               // 56
      after: { // This methods, if defined, will be called after the POST/GET/PUT/DELETE actions are performed on the collection.
        // Generally, you don't need this, unless you have global variable to reflect data inside collection.          // 78
        // The function doesn't need return value.                                                                     // 79
        POST: undefined, // function() {console.log("After POST");},                                                   // 80
        GET: undefined, // function() {console.log("After GET");},                                                     // 81
        PUT: undefined, // function() {console.log("After PUT");},                                                     // 82
        DELETE: undefined // function() {console.log("After DELETE");},                                                // 83
      }                                                                                                                // 77
    });                                                                                                                // 51
                                                                                                                       //
    // Add the collection Users to the API "/players" path                                                             // 87
    collectionApi.addCollection(ModelSheets, 'modelsheets', {                                                          // 88
      // All values listed below are default                                                                           // 89
      authToken: undefined, // Require this string to be passed in on each request.                                    // 90
      authenticate: undefined, // function(token, method, requestMetadata) {return true/false}; More details can found in [Authenticate Function](#Authenticate-Function).
      methods: ['POST', 'GET', 'PUT', 'DELETE'], // Allow creating, reading, updating, and deleting                    // 92
      before: { // This methods, if defined, will be called before the POST/GET/PUT/DELETE actions are performed on the collection.
        // If the function returns false the action will be canceled, if you return true the action will take place.   // 94
        POST: function () {                                                                                            // 95
          function POST(obj, requestMetadata, returnObject) {                                                          // 95
            obj.createdAt = new Date();                                                                                // 96
            return true;                                                                                               // 97
          }                                                                                                            // 98
                                                                                                                       //
          return POST;                                                                                                 // 95
        }(), // function(obj, requestMetadata, returnObject) {return true/false;},                                     // 95
        GET: undefined, // function(objs, requestMetadata, returnObject) {return true/false;},                         // 99
        PUT: function () {                                                                                             // 100
          function PUT(obj, requestMetadata, returnObject) {                                                           // 100
            console.log('PUT', obj['private']);                                                                        // 101
            return true;                                                                                               // 102
          }                                                                                                            // 103
                                                                                                                       //
          return PUT;                                                                                                  // 100
        }(), // function(obj, newValues, requestMetadata, returnObject) {return true/false;},                          // 100
        DELETE: undefined // function(obj, requestMetadata, returnObject) {return true/false;}                         // 104
      },                                                                                                               // 93
      after: { // This methods, if defined, will be called after the POST/GET/PUT/DELETE actions are performed on the collection.
        // Generally, you don't need this, unless you have global variable to reflect data inside collection.          // 107
        // The function doesn't need return value.                                                                     // 108
        POST: undefined, // function() {console.log("After POST");},                                                   // 109
        GET: undefined, // function() {console.log("After GET");},                                                     // 110
        PUT: undefined, // function() {console.log("After PUT");},                                                     // 111
        DELETE: undefined // function() {console.log("After DELETE");},                                                // 112
      }                                                                                                                // 106
    });                                                                                                                // 88
                                                                                                                       //
    // Starts the API server                                                                                           // 116
    collectionApi.start();                                                                                             // 117
  });                                                                                                                  // 118
}                                                                                                                      // 119
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
